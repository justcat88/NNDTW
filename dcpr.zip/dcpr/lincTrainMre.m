function [recogRate, coef, regError]=lincTrainMre(DS, CParam, plotOpt)
% lincTrainMre: Linear classifier training for min. regression error
%	Usage: [recogRate, coef, regError]=lincTrainMre(DS, CParam, plotOpt)

% Roger Jang, 20040926

if nargin<1, selfdemo; return; end
if nargin<2, CParam=[]; end
if nargin<3, plotOpt=0; end

[dim, dataNum]=size(DS.input);
% Preapre A matrix for A*x=desired
A=[DS.input', ones(dataNum,1)];
uniqueOutput=unique(DS.output);
if length(uniqueOutput)~=2, error('Must be 2-class problem!'); end
% �N DS.output �令 -1 �� 1
index=find(DS.output==max(uniqueOutput));
DS.output=-ones(1, size(DS.output,2));
DS.output(index)=1;
% Prepare desired vector to be -1 or 1
desired=-ones(dataNum, 1);
desired(DS.output>0)=1;
coef=A\desired;


[lincOutput, recogRate, regOutput, regError]=lincEval(DS, coef);

%computed=A*coef;					% Computed regression output
%regError=sum((computed-desired).^2);		% Regression MSE
%computed2=-ones(dataNum, 1);			% Computed classification output
%computed2(computed>0)=1;
%recogRate=sum(computed2==desired)/dataNum;	% Classification recognition rate

if plotOpt & dim==2
	dcprDataPlot(DS); axis image
	xMin=min(DS.input(1,:));
	xMax=max(DS.input(1,:));
	yMin=min(DS.input(2,:));
	yMax=max(DS.input(2,:));
	a=coef(1); b=coef(2); c=coef(3);
	x1=xMin;
	y1=(-c-a*x1)/b;
	x2=xMax;
	y2=(-c-a*x2)/b;
	line([x1, x2], [y1, y2], 'color', 'k');
end

% ====== Self demo
function selfdemo
dataNum=100;
DS.input=2*rand(2, dataNum)-1;
DS.output=DS.input(1,:)+DS.input(2,:)>0;
plotOpt=1;
[recogRate, coef, regError]=feval(mfilename, DS, [], plotOpt);
fprintf('Regression MSE = %f\n', regError);
fprintf('Recognition rate = %f%%\n', recogRate*100);
fprintf('Coef = %s\n', mat2str(coef));