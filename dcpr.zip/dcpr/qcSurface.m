function surfObj=qcSurface(DS, pointNum, classParam)
% qcSurface: Compute the surface object of each class within a quadratic classifier
%	Usage: surfObj=qcSurface(DS, pointNum, classParam)
%
%	For example:
%
%		DS = prData('iris');
%		DS.input=DS.input(3:4, :);			% Use only dimensions 3 and 4
%		classParam=qcTrain(DS);
%		pointNum=100;
%		surfObj=qcSurface(DS, pointNum, classParam);	% Compute the surface object of each class
%		classNum=length(surfObj.class);
%		% Plot the surfaces (�e�X������)
%		for i=1:classNum
%			subplot(1,3,i);
%			mesh(surfObj.xx, surfObj.yy, surfObj.class(i).surface);
%			title(['PDF of class ', num2str(i)]);
%			axis([-inf inf -inf inf -inf inf]);
%		end

%	Roger Jang, 20090413

if nargin<1, selfdemo; return; end
if nargin<2, pointNum=100; end
if nargin<3
	classWeight=classDataCount(DS);	% classWeight (or priors) is equal to the data count of each class
	classParam=qcTrain(DS, classWeight);
end

% PDF for each class
x=linspace(min(DS.input(1,:)), max(DS.input(1,:)), pointNum);
y=linspace(min(DS.input(2,:)), max(DS.input(2,:)), pointNum);
[xx, yy] = meshgrid(x, y);
data = [xx(:), yy(:)]';
classNum=length(classParam);
for i=1:classNum
	out = gaussian(data, classParam(i));
	surfObj.class(i).surface = classParam(i).weight*reshape(out, pointNum, pointNum);	% Multiplied by priors
	surfObj.class(i).param = classParam(i);
end

surfObj.xx=xx;
surfObj.yy=yy;

% ====== Self demo
function selfdemo
DS = prData('iris');
DS.input=DS.input(3:4, :);			% Use only dimensions 3 and 4
classWeight=classDataCount(DS);			% Use the class size as its weight for computing the priors (�H�C�@�����O����ƶq�������O���v��)
classParam=qcTrain(DS, classWeight);
pointNum=100;
surfObj=qcSurface(DS, pointNum, classParam);	% Compute the surface object of each class (�p��C�����O�������K�ר�ƪ�����)
classNum=length(surfObj.class);
% Plot the surfaces (�e�X������)
for i=1:classNum
	subplot(2,3,i);
	mesh(surfObj.xx, surfObj.yy, surfObj.class(i).surface);
	title(['PDF of class ', num2str(i)]);
	axis([-inf inf -inf inf -inf inf]);
end
% Plot the contours (�e�X�����u)
for i=1:classNum
	subplot(2,3,3+i);
	contourf(surfObj.xx, surfObj.yy, surfObj.class(i).surface, 30);
	shading flat; colorbar
end