// This is equivalent to gmmEval.m
// How to compile:
// mex -Id:/users/jang/c/lib -Id:/users/jang/c/lib/dcpr gmmEvalMex.cpp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/utility.cpp

#include <string.h>
#include <math.h>
#include "mex.h"
#include "dcpr.hpp"

/* Input Arguments */
#define	DATA		prhs[0]
#define	INGMMPARAM	prhs[1]
/* Output Arguments */
#define	LOGPROB		plhs[0]
#define EACHPROB	plhs[1]
			
void mexFunction(
	int nlhs,	mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	double *data, *mu, *sigma, *w, *logProb, *eachProb;
	int i, j, dim, dataNum, gaussianNum, sigmaDim;
	
	/* Check for proper number of arguments */
	if (nrhs<2) {
		char message[200];
		strcpy(message, mexFunctionName());
		strcat(message, " requires 2 input arguments.\n");
		strcat(message, "Usage: logProb = ");
		strcat(message, mexFunctionName());
		strcat(message, "(data, gmmParam)");
		mexErrMsgTxt(message);
	}
	
	/* Dimensions of the input matrix */
	dim = mxGetM(DATA);
	dataNum = mxGetN(DATA);
	gaussianNum = mxGetN(INGMMPARAM);
	
	/* Create a matrix for the return argument */
	LOGPROB = mxCreateDoubleMatrix(1, dataNum, mxREAL);
	logProb = mxGetPr(LOGPROB);
	if (nlhs<2){
		eachProb=(double *)malloc(gaussianNum*dataNum*sizeof(double));
	} else {
		EACHPROB=mxCreateDoubleMatrix(gaussianNum, dataNum, mxREAL);
		eachProb=mxGetPr(EACHPROB);
	}	

	// Create gmm Object for gmmEval().
	GMMPARAM gmm;
	gmm.dim=dim;
	gmm.mixNum=gaussianNum;
	gmm.mean=	(double *)calloc(gmm.dim*gmm.mixNum, sizeof(double));
	gmm.covariance=	(double *)calloc(gmm.mixNum, sizeof(double));
	gmm.weight=	(double *)calloc(gmm.mixNum, sizeof(double));
	gmm.gConst=	(double *)calloc(gmm.mixNum, sizeof(double));	// Not used, but declared since it'll be freed in gmmFree(). (If this is not declared, memory error occurs.)

	// Put MATLAB data structures into C data structures
	mxArray *fieldValue;
	for (i=0; i<gaussianNum; i++){
		fieldValue=mxGetField(INGMMPARAM, i, "mu");		mu=mxGetPr(fieldValue);
		for (j=0; j<gmm.dim; j++) gmm.mean[i*gmm.dim+j]=mu[j];
		
		fieldValue=mxGetField(INGMMPARAM, i, "sigma");	sigma=mxGetPr(fieldValue); sigmaDim=mxGetM(fieldValue)*mxGetN(fieldValue);
		gmm.covariance[i]=sigma[0];
		
		fieldValue=mxGetField(INGMMPARAM, i, "w");		w=mxGetPr(fieldValue);
		gmm.weight[i]=w[0];
	}
	strcpy(gmm.comment, "Converted from MATLAB");
	strcpy(gmm.version, "0.0.0");
	strcpy(gmm.name, "This is the name of the GMM");
	if (sigmaDim==1)
		gmm.gmmType=1;
	else if (sigmaDim==dim)
		gmm.gmmType=2;
	else if (sigmaDim==dim*dim)
		gmm.gmmType=3;
	else
		mexErrMsgTxt("Unknown covariance type!");
	
gmmPrint(gmm);

	// GMM evaluation
	gmmEval(data, dim, dataNum, gmm, logProb, eachProb);
	gmmFree(gmm);
	
	if (nlhs<2)
		free(eachProb);
}