// How to compile:
// MATLAB 7.1: mex dtw2freeUpMex.cpp d:/users/jang/c/lib/dtw.cpp -output dtw2freeUpMex.dll
// Others: mex dtw2freeUpMex.cpp d:/users/jang/c/lib/dtw.cpp

#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "mex.h"
#include "dtw.hpp"

/* Input Arguments */
#define VEC1		prhs[0]    /*      test input, idx = i */
#define VEC2		prhs[1]    /* reference input, idx = j */
#define BEGINCORNER	prhs[2]
#define ENDCORNER	prhs[3]
#define FREEUP		prhs[4]

/* Output Arguments */
#define	MINDISTANCE	plhs[0]
#define DTWPATH plhs[1]

void mexFunction(
	int nlhs,	mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	int size1, size2, featureDim, featureDim2, i, beginCorner, endCorner, DTWpathLen, freeUp;
	double *vec1, *vec2, *minDistance, *DTWpath, *returnedDTWpath;

	/* Check for proper number of input arguments */
	if ((nrhs<2)||(nrhs>5)) {
		char message[200];
		strcpy(message, "Usage: ");
		strcat(message, mexFunctionName());
		strcat(message, " vec1 vec2 beginCorner endCorner freeUp");

		strcpy(message, mexFunctionName());
		strcat(message, " requires 2 input arguments.\n");
		strcat(message, "Usage: [minDistance, dtwPath] = ");
		strcat(message, mexFunctionName());
		strcat(message, "(vec1, vec2, beginCorner, endCorner, freeUp)");
		mexErrMsgTxt(message);
	}

	/* Error checking */
	featureDim  = mxGetM(VEC1);
	featureDim2 = mxGetM(VEC2);
	if (featureDim!=featureDim2)
		mexErrMsgTxt("Feature dimensions of input vectors mismatch!");

	size1 = mxGetN(VEC1);
	size2 = mxGetN(VEC2);
	if ((size1==0) || (size2==0))
		mexErrMsgTxt("One or two of the input vectors is empty!");

	/* Default values */
	beginCorner = 1;
	endCorner = 1;
	freeUp = 0;
	if (nrhs>=3) beginCorner = (int)(mxGetPr(BEGINCORNER)[0]);
	if (nrhs>=4) endCorner = (int)(mxGetPr(ENDCORNER)[0]);
	if (nrhs>=5) freeUp = (int)(mxGetPr(FREEUP)[0]);

	/* Assign pointers to the input arguments */
	vec1 = mxGetPr(VEC1);
	vec2 = mxGetPr(VEC2);

	/* Output min. distance and DTW path*/
	MINDISTANCE = mxCreateDoubleMatrix(1, 1, mxREAL);
	minDistance  = mxGetPr(MINDISTANCE);
	minDistance[0] = dtw2freeUp(vec1, size1, vec2, size2, featureDim, beginCorner, endCorner, freeUp, &DTWpathLen, &returnedDTWpath);
	if (DTWpathLen>0) {
		DTWPATH = mxCreateDoubleMatrix(2, DTWpathLen, mxREAL);
		DTWpath = mxGetPr(DTWPATH);
		for (i=0; i<2*DTWpathLen; i++)
			DTWpath[i] = returnedDTWpath[i]+1;	// Plus one for MATLAB indexing
		free(returnedDTWpath);	// Free returnedDTWpath, which was create within dtw().
	} else
		DTWPATH = mxCreateDoubleMatrix(0, 0, mxREAL);
}
