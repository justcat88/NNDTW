dbstop if error

fprintf('Compiling gmmEvalIntMex.cpp...\n');
mex gmmEvalIntMex.cpp -Id:/users/jang/c/lib -Id:/users/jang/c/lib/dcpr -Id:/users/jang/c/lib/tableLookUp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/dcpr/dcprInt.cpp d:/users/jang/c/lib/utility.cpp

fprintf('Loading gmmParam.mat and speakerData.mat...\n');
load gmmParam.mat
load speakerData.mat

fprintf('Testing gmmEvalIntMex...\n');
%i=1;
%j=1;
%k=1;
%logProb=gmmEvalIntMex(speakerData1(i).sentence(j).mfcc, gmm(k).mean, gmm(k).covariance, gmm(k).weight)
%return

speakerData=speakerData1;
useIntGmm=1;
speakerNum=length(speakerData);
for i=1:speakerNum
	fprintf('%d/%d: Recognizing wave files by %s\n', i, speakerNum, speakerData(i).name);
	for j=1:length(speakerData(i).sentence),
%		fprintf('\tj=%d/%d\n', j, length(speakerData(i).sentence))
		frameNum=size(speakerData(i).sentence(j).mfcc, 2);
		logProb=zeros(speakerNum, frameNum); 
		for k=1:speakerNum,
		%	logProb(k, :)=gmmEval(speakerData(i).sentence(j).mfcc, gmm(k).mean, gmm(k).covariance, gmm(k).weight);
			if ~useIntGmm
				logProb(k, :)=gmmEvalMex(speakerData(i).sentence(j).mfcc, gmm(k).mean, gmm(k).covariance, gmm(k).weight);
			else
				logProb(k, :)=gmmEvalIntMex(speakerData(i).sentence(j).mfcc, gmm(k).mean, gmm(k).covariance, gmm(k).weight);
			end
		end
		cumLogProb=sum(logProb, 2);
		[maxProb, index]=max(cumLogProb);
		speakerData(i).sentence(j).predictedSpeaker=index;
		speakerData(i).sentence(j).logProb=logProb;
	end
end