% ====== Test on vecdist2.dll and vecdist2.m

fprintf('Copying vecdist.m to vecdistm.m ...\n');
dos('copy vecdist.m vecdistm.m');
fprintf('Copying vecdist2.m to vecdist2m.m ...\n');
dos('copy vecdist2.m vecdist2m.m');

x = rand(100,30);
y = rand(50,30);
distort = rand(1,30);

t0 = clock;
dist1 = vecdist(x*diag(distort), y*diag(distort));
time1 = etime(clock, t0);
t0 = clock;
dist2 = vecdistm(x*diag(distort), y*diag(distort));
time2 = etime(clock, t0);
t0 = clock;
dist3 = vecdist2(x, y, distort);
time3 = etime(clock, t0);
t0 = clock;
dist4 = vecdist2m(x, y, distort);
time4 = etime(clock, t0);

diff12 = max(max(dist1-dist2));
diff34 = max(max(dist3-dist4));
diff13 = max(max(dist1-dist3));
fprintf('With distortion:\n');
fprintf('Elapsed time for vecdist.dll: %g\n', time1);
fprintf('Elapsed time for vecdist.m: %g\n', time2);
fprintf('Elapsed time for vecdist2.dll: %g\n', time1);
fprintf('Elapsed time for vecdist2.m: %g\n', time2);
fprintf('Diff. between vecdist.dll and vecdist.m: %g\n', diff12);
fprintf('Diff. between vecdist2.dll and vecdist2.m: %g\n', diff34);
fprintf('Diff. between vecdist.dll and vecdist2.dll: %g\n', diff13);

fprintf('\n');

% ====== Test on vecdist.dll, vecdist.m, vecdist2.dll and vecdist2.m

x = rand(100,30);
y = rand(50,30);

t0 = clock;
dist1 = vecdist(x, y);
time1 = etime(clock, t0);
t0 = clock;
dist2 = vecdistm(x, y);
time2 = etime(clock, t0);
t0 = clock;
dist3 = vecdist2(x, y);
time3 = etime(clock, t0);
t0 = clock;
dist4 = vecdist2m(x, y);
time4 = etime(clock, t0);

diff12 = max(max(dist1-dist2));
diff34 = max(max(dist3-dist4));
diff13 = max(max(dist1-dist3));
fprintf('Without distortion:\n');
fprintf('Elapsed time for vecdist.dll: %g\n', time1);
fprintf('Elapsed time for vecdist.m: %g\n', time2);
fprintf('Elapsed time for vecdist2.dll: %g\n', time1);
fprintf('Elapsed time for vecdist2.m: %g\n', time2);
fprintf('Diff. between vecdist.dll and vecdist.m: %g\n', diff12);
fprintf('Diff. between vecdist2.dll and vecdist2.m: %g\n', diff34);
fprintf('Diff. between vecdist.dll and vecdist2.dll: %g\n', diff13);

fprintf('\nDeleting vecdistm.m ...\n');
delete vecdistm.m
fprintf('Deleting vecdist2m.m ...\n');
delete vecdist2m.m
