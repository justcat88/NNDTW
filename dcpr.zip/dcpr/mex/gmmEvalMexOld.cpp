// This is equivalent to gmmEval.m
// How to compile:
// mex -Id:/users/jang/c/lib -Id:/users/jang/c/lib/dcpr gmmEvalMex.cpp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/utility.cpp

#include <string.h>
#include <math.h>
#include "mex.h"
#include "dcpr.hpp"

/* Input Arguments */
#define	DATA		prhs[0]
#define	MEAN		prhs[1]
#define	COVARIANCE	prhs[2]
#define WEIGHT		prhs[3]
/* Output Arguments */
#define	LOGPROB		plhs[0]
#define EACHPROB	plhs[1]
			
void mexFunction(
	int nlhs,	mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	double *data, *mean, *covariance, *weight, *logProb, *eachProb;
	int i, dim, dataNum, gaussianNum, sigmaDim;
	char message[200];

	/* Check for proper number of arguments */
	if (nrhs<4) {
		strcpy(message, mexFunctionName());
		strcat(message, " requires 4 input arguments.\n");
		strcat(message, "Usage: logProb = ");
		strcat(message, mexFunctionName());
		strcat(message, "(data, M, V, W)");
		mexErrMsgTxt(message);
	}
	
	/* Dimensions of the input matrix */
	dim = mxGetM(DATA);
	dataNum = mxGetN(DATA);
	gaussianNum = mxGetN(MEAN);

	/* Create a matrix for the return argument */
	LOGPROB = mxCreateDoubleMatrix(1, dataNum, mxREAL);
	logProb = mxGetPr(LOGPROB);
	if (nlhs<2){
		eachProb=(double *)malloc(gaussianNum*dataNum*sizeof(double));
	} else {
		EACHPROB=mxCreateDoubleMatrix(gaussianNum, dataNum, mxREAL);
		eachProb=mxGetPr(EACHPROB);
	}	

	/* Assign pointers to the various parameters */
	data = mxGetPr(DATA);
	mean = mxGetPr(MEAN);
	covariance = mxGetPr(COVARIANCE);
	weight = mxGetPr(WEIGHT);

	// Create gmm Object for gmmEval().
	GMMPARAM gmm;
	gmm.dim=dim;
	gmm.mixNum=gaussianNum;
	gmm.mean=	(double *)calloc(gmm.dim*gmm.mixNum, sizeof(double));
	gmm.covariance=	(double *)calloc(gmm.mixNum, sizeof(double));
	gmm.weight=	(double *)calloc(gmm.mixNum, sizeof(double));
	gmm.gConst=	(double *)calloc(gmm.mixNum, sizeof(double));	// Not used, but declared since it'll be freed in gmmFree(). (If this is not declared, memory error occurs.)
	for (i=0; i<gmm.dim*gmm.mixNum; i++) gmm.mean[i]=mean[i];
	for (i=0; i<gmm.mixNum; i++) gmm.covariance[i]=covariance[i];
	for (i=0; i<gmm.mixNum; i++) gmm.weight[i]=weight[i];
	
	strcpy(gmm.comment, "Converted from MATLAB");
	strcpy(gmm.version, "0.0.0");
	strcpy(gmm.name, "This is the name of the GMM");
	sigmaDim=mxGetM(COVARIANCE)*mxGetN(COVARIANCE)/gaussianNum;

	if (sigmaDim==1)
		gmm.gmmType=1;
	else if (sigmaDim==dim)
		gmm.gmmType=2;
	else if (sigmaDim==dim*dim)
		gmm.gmmType=3;
	else
		mexErrMsgTxt("Unknown covariance type!");

gmmPrint(gmm);

	// GMM evaluation
	gmmEval(data, dim, dataNum, gmm, logProb, eachProb);
	gmmFree(gmm);
	
	if (nlhs<2)
		free(eachProb);
}