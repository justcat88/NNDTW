addpath ..

%fprintf('Compiling mixLogSumMex.cpp...\n');
%mex mixLogSumMex.cpp d:/users/jang/c/lib/dcpr.cpp d:/users/jang/c/lib/utility.cpp

input=-2000:-1000;
tic; out1=log(sum(exp(input))); time1=toc;
fprintf('time1=%g, out1=%g\n', time1, out1);

tic; out2=mixLogSum(input); time2=toc;
fprintf('time2=%g, out2=%g\n', time2, out2);

tic; out3=mixLogSumMex(input); time3=toc;
fprintf('time3=%g, out3=%g\n', time3, out3);