% Compute the distance between a given vector and 1000 other vectors

% Compile dtw4jimmy.cpp
mex dtw4jimmy.cpp

n=1000;
vec=round(100*randn(1, 150));
mat=round(100*randn(n, 200));
dist=zeros(n, 1);

tic
for i=1:n
	dist(i)=dtw4jimmy(vec, mat(i,:), 1, 1);
end
fprintf('Time = %.3f sec\n', toc);