copyfile('..\lcs.m', 'lcsm.m');
a = '�ڪ���󧨩M�����W���ھF';
b = '�A�ڹq��������󪺪ھF�P�ڪ�����';

% ====== test lcs.dll file
n = 1000;
t0 = clock;
for i = 1:n,
	count = lcs(a, b);
end
time1 = etime(clock, t0);
fprintf('Execution time for lcs.m: %g\n', time1);

% ====== test lcsm.m file
t0 = clock;
for i = 1:n,
	count1 = lcsmex(a, b);
end
time2 = etime(clock, t0);
fprintf('Execution time for lcsmex.mexw32: %g\n', time2);

fprintf('Speedup factors:\n');
fprintf('lcsm.m    ==> %g/%g = %g\n', time1, time2, time1/time2);

n=1000;
for i=1:n
	fprintf('%d/%d\n', i, n);
	a=char('a'+floor(rand(1,10)*26));
	b=char('a'+floor(rand(1,15)*26));
	count1=lcsm(a, b);
	count2=lcsmex(a, b);
	if count1~=count2
		fprintf('Mismatch!\n');
		fprintf('a=%s\n', a);
		fprintf('b=%s\n', b);
		fprintf('count1=%d\n', count1);
		fprintf('count2=%d\n', count2);
		return;
	end
end