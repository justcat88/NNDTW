// This is equivalent to gaussianLog.m
// How to compile:
// mex -Id:/users/jang/c/lib -Id:/users/jang/c/lib/utility -Id:/users/jang/c/lib/dcpr gaussianMex.cpp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/utility/utility.cpp

#include <string.h>
#include <math.h>
#include "mex.h"
#include "dcpr.hpp"

/* Input Arguments */
#define DATA		prhs[0]
#define GPARAM		prhs[1]
/* Output Arguments */
#define LOGPROB		plhs[0]
			
void mexFunction(
	int nlhs,	mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	double *data, *mu, *sigma, *logProb;
	int i, dim, dataNum, sigmaDim;
	

	/* Check for proper number of arguments */
	if (nrhs<2){
		char message[200];
		strcpy(message, mexFunctionName());
		strcat(message, " requires 2 input arguments.\n");
		strcat(message, "Usage: logProb = ");
		strcat(message, mexFunctionName());
		strcat(message, "(data, gParam)");
		strcat(message, "\n\t(Note that gParam.sigma must be a scalar!)");
		mexErrMsgTxt(message);
	}

	/* Dimensions of the input matrix */
	dim = mxGetM(DATA);
	dataNum = mxGetN(DATA);

	/* Create a matrix for the return argument */
	LOGPROB = mxCreateDoubleMatrix(1, dataNum, mxREAL);
	logProb = mxGetPr(LOGPROB);

	/* Assign pointers to the various parameters */
	data = mxGetPr(DATA);
	mxArray *fieldValue;
	fieldValue=mxGetField(GPARAM, 0, "mu");		mu=mxGetPr(fieldValue);
	fieldValue=mxGetField(GPARAM, 0, "sigma");	sigma=mxGetPr(fieldValue); sigmaDim=mxGetM(fieldValue)*mxGetN(fieldValue);

	vecPrint(mu, dim);
	vecPrint(sigma, dim);

	if (sigmaDim==1)
		for (i=0; i<dataNum; i++)
			logProb[i]=gaussian01Log(data+i*dim, dim, mu, sigma);
	else if (sigmaDim==dim)
		for (i=0; i<dataNum; i++)
			logProb[i]=gaussian02Log(data+i*dim, dim, mu, sigma);
	else if (sigmaDim==dim*dim)
			mexErrMsgTxt("Full covariance matrix is not supported!");
}