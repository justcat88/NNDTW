addpath d:/users/jang/matlab/toolbox/dcpr

fprintf('Traing GMM...\n');
DS=prData('iris');
gmmParam=gmmTrain(DS.input, [8, 1]);
dataNum=100000;
dim=length(gmmParam(1).mu);
data=100*rand(dim, dataNum);

fprintf('Compiling gmmEvalMex.cpp & gmmEvalMexOld.cpp ...\n');
mex -Id:/users/jang/c/lib -Id:/users/jang/c/lib/utility -Id:/users/jang/c/lib/dcpr -Id:/users/jang/c/lib/mfccInt gmmEvalMex.cpp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/utility/utility.cpp -output gmmEvalMex.dll
mex -Id:/users/jang/c/lib -Id:/users/jang/c/lib/utility -Id:/users/jang/c/lib/dcpr -Id:/users/jang/c/lib/mfccInt gmmEvalMexOld.cpp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/utility/utility.cpp -output gmmEvalMexOld.dll

fprintf('Testing gmmEvalMex.cpp...\n');
tic, [logProb1, eachProb1]=gmmEval(data, gmmParam); time1=toc;
tic, [logProb2, eachProb2]=gmmEvalMexOld(data, [gmmParam.mu], [gmmParam.sigma], [gmmParam.w]); time2=toc;
tic, [logProb3, eachProb3]=gmmEvalMex(data, gmmParam); time2=toc;

fprintf('Difference in logProb1 and logProb2 = %g\n', sum(abs(logProb1-logProb2)));
fprintf('Difference in eachProb1 and eachProb2 = %g\n', sum(sum(abs(eachProb1-eachProb2))));
fprintf('time1/time2=%g/%g=%g\n', time1, time2, time1/time2);
fprintf('Difference in logProb1 and logProb3 = %g\n', sum(abs(logProb1-logProb3)));
fprintf('Difference in eachProb1 and eachProb3 = %g\n', sum(sum(abs(eachProb1-eachProb3))));