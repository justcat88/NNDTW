// This is equivalent to mixLogSum.m
// How to compile:
// MATLAB 7.1: mex mixLogSumMex.cpp d:/users/jang/c/lib/dcpr.cpp d:/users/jang/c/lib/utility.cpp -output mixLogSumMex.dll
// Others: mex mixLogSumMex.cpp d:/users/jang/c/lib/dcpr.cpp d:/users/jang/c/lib/utility.cpp
/* Roger Jang, 20070324 */

#include <math.h>
#include "mex.h"
#include "dcpr.hpp"

/* Input Arguments */
#define	INPUT	prhs[0]
/* Output Arguments */
#define	OUTPUT	plhs[0]

void mexFunction(
	int nlhs,	mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	double	*input, *output;
	int i, m, n;

	/* Check for proper number of arguments */
	if ((nrhs<1) || (nrhs>2))
		mexErrMsgTxt("VECDIST requires one or two input arguments.");
	else if (nlhs > 1)
		mexErrMsgTxt("VECDIST requires one output argument.");

	/* Check dimensions */
	m = mxGetM(INPUT);
	n = mxGetN(INPUT);

	/* Create a matrix for the return argument */
	OUTPUT = mxCreateDoubleMatrix(1, 1, mxREAL);

	/* Assign pointers to the various parameters */
	input = mxGetPr(INPUT);
	output = mxGetPr(OUTPUT);

	/* Do the actual computations */
	output[0]=mixLogSum(input, m*n);
}