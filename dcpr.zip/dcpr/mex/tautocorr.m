% ====== Test on autocorr.m and autocorr.c

%fprintf('Copying autocorr.m to autocorrm.m ...\n');
%dos('copy autocorr.m autocorrm.m');

t = linspace(0, 20*pi, 256);
frame = cos(t)+randn(size(t))/3;

t0 = clock;
for i=1:500, out1 = autocorr(frame);end
time1 = etime(clock, t0);
t0 = clock;
for i=1:500, out2 = autocorrm(frame);end
time2 = etime(clock, t0);

diff = max(abs(out1-out2));

fprintf('Elapsed time for autocorr.dll: %g\n', time1);
fprintf('Elapsed time for autocorr.m: %g\n', time2);
fprintf('Diff. between vecdist.dll and vecdist.m: %g\n', diff);
