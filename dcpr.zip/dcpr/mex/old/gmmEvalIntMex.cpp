// This is the fix-point version of gmmEvalMex.dll
// How to compile:
// mex gmmEvalIntMex.cpp -Id:/users/jang/c/lib -Id:/users/jang/c/lib/dcpr -Id:/users/jang/c/lib/tableLookUp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/dcpr/dcprInt.cpp d:/users/jang/c/lib/utility.cpp

#include <string.h>
#include <math.h>
#include "mex.h"
#include "utility.h"
#include "dcpr.h"
#include "dcprIntCpp.h"
#include "logTableVar.h"
#include "logTable.inc"
#include "mixLogSumTableVar.h"
#include "mixLogSumTable.inc"

/* Input Arguments */
#define	DATA		prhs[0]
#define	MEAN		prhs[1]
#define	COVARIANCE	prhs[2]
#define WEIGHT		prhs[3]
/* Output Arguments */
#define	LOGPROB		plhs[0]

FILE *globalFid;
			
void mexFunction(
	int nlhs,	mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	double *data, *mean, *covariance, *weight, *logProb, *eachProb;
	int i, dim, dataNum, gaussianNum, *dataInt, *logProbInt, *eachProbInt;
	char message[200];
	
	

	/* Check for proper number of arguments */
	if (nrhs<4) {
		strcpy(message, mexFunctionName());
		strcat(message, " requires 4 input arguments.\n");
		strcat(message, "Usage: logProb = ");
		strcat(message, mexFunctionName());
		strcat(message, "(data, M, V, W)");
		mexErrMsgTxt(message);
	}

	/* Dimensions of the input matrix */
	dim = mxGetM(DATA);
	dataNum = mxGetN(DATA);
	gaussianNum = mxGetN(MEAN);

	/* Create a matrix for the return argument */
	LOGPROB = mxCreateDoubleMatrix(1, dataNum, mxREAL);
	logProb = mxGetPr(LOGPROB);

	/* Assign pointers to the various parameters */
	data = mxGetPr(DATA);
	mean = mxGetPr(MEAN);
	covariance = mxGetPr(COVARIANCE);
	weight = mxGetPr(WEIGHT);
	
	// Convert to integer
	eachProbInt=(int *)malloc(gaussianNum*dataNum*sizeof(int));
	logProbInt=(int *)malloc(dataNum*sizeof(int));
	dataInt=(int *)malloc(dim*dataNum*sizeof(int)); double2intVec(data, dim*dataNum, dataInt);

	// Create gmm Object for gmmEval().
	GMMPARAMINT gmm;
	gmm.dim=dim;
	gmm.mixNum=gaussianNum;
	gmm.mean=	(int *)malloc(gmm.dim*gmm.mixNum*sizeof(int));
	gmm.covariance=	(int *)malloc(gmm.mixNum*sizeof(int));
	gmm.weight=	(int *)malloc(gmm.mixNum*sizeof(int));
	gmm.gConst=	(int *)malloc(gmm.mixNum*sizeof(int));
	for (i=0; i<gmm.dim*gmm.mixNum; i++) gmm.mean[i]=myRound(mean[i]);
	for (i=0; i<gmm.mixNum; i++) gmm.covariance[i]=myRound(covariance[i]);
	for (i=0; i<gmm.mixNum; i++) gmm.weight[i]=myRound(LOGTABLE_Y_SF*weight[i]);				// �ƹ�W�O�� log(w)
	for (i=0; i<gmm.mixNum; i++) gmm.gConst[i]=myRound(-LOGTABLE_Y_SF*dim*log(2.0*PI*covariance[i])/2.0);	// gConst �]�ݭn��j
//	for (i=0; i<gmm.mixNum; i++)	// Correct the value of covariance
//		if (gmm.covariance[i]==0)
//			gmm.covariance[i]=1;
	// GMM evaluation
	globalFid=openFile("temp.txt", "a");
	gmmEvalInt(dataInt, dim, dataNum, gmm, logProbInt, eachProbInt);
	fclose(globalFid);
	gmmFreeInt(gmm);
	int2doubleVec(logProbInt, dataNum, logProb);
	
	free(eachProbInt);
	free(logProbInt);
	free(dataInt);
}