// This is equivalent to gaussian.m
// How to compile:
// MATLAB 7.1: mex gaussianMex.cpp d:/users/jang/c/lib/dcpr.cpp d:/users/jang/c/lib/utility.cpp -output gaussianMex.dll
// Others: mex -Id:/users/jang/c/lib -Id:/users/jang/c/lib/dcpr gaussianMex.cpp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/utility.cpp

#include <string.h>
#include <math.h>
#include "mex.h"
#include "dcpr.h"

/* Input Arguments */
#define	DATA		prhs[0]
#define	MEAN		prhs[1]
#define	COVARIANCE	prhs[2]
/* Output Arguments */
#define	PROB		plhs[0]
			
void mexFunction(
	int nlhs,	mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	double *data, *mean, covariance, *weight, *prob;
	int i, dim, dataNum, gaussianNum;
	double *eachProb;
	char message[200];

	/* Check for proper number of arguments */
	if (nrhs<3) {
		strcpy(message, mexFunctionName());
		strcat(message, " requires 3 input arguments.\n");
		strcat(message, "Usage: prob = ");
		strcat(message, mexFunctionName());
		strcat(message, "(data, mean, covariance)");
		strcat(message, "\n\t(Note that covariance must be a scalar!)");
		mexErrMsgTxt(message);
	}

	/* Dimensions of the input matrix */
	dim = mxGetM(DATA);
	dataNum = mxGetN(DATA);

	/* Create a matrix for the return argument */
	PROB = mxCreateDoubleMatrix(1, dataNum, mxREAL);
	prob = mxGetPr(PROB);

	/* Assign pointers to the various parameters */
	data = mxGetPr(DATA);
	mean = mxGetPr(MEAN);
	covariance = mxGetScalar(COVARIANCE);
	
	for (i=0; i<dataNum; i++)
		prob[i]=gaussian(data+i*dim, dim, mean, covariance);
}