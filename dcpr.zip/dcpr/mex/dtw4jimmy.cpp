// How to compile: mex dtw4jimmy.cpp

#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>		// For using mxGetInf()
#include "mex.h"

#define INF		10000000000.0
#define MAX(x,y)	((x)>(y)?(x):(y))
#define MIN(x,y)	((x)<(y)?(x):(y))
typedef struct {
	int i, j;
} POSITION;

/* Input Arguments */
#define VEC1		prhs[0]		/*      test input, idx = i */
#define VEC2		prhs[1]		/* reference input, idx = j */
#define BEGINCORNER	prhs[2]
#define ENDCORNER	prhs[3]
#define LOWERBOUND	prhs[4]

/* Output Arguments */
#define	MINDISTANCE	plhs[0]
#define DTWPATH 	plhs[1]
#define DTWTABLE 	plhs[2]

// Return the overall minimum distance and the last best position (*pLastJ)
double findMinDistInDtwTable(double **dtwTable, int size1, int size2, int endCorner, int *pLastJ){
	int j, lastBestj;
	double minDist;
	if (endCorner==1){	// Min. at corner
		minDist=dtwTable[size1-1][size2-1];
		lastBestj=size2-1;
	} else {		// Min. at the rightmost side (xy view)
		minDist=INF;
//		k=(int)ceil((double)(size1-1)/2);
//		for (j=k; j<size2; j++)
		for (j=0; j<size2; j++)
			if (dtwTable[size1-1][j]<minDist){
				minDist=dtwTable[size1-1][j];
				lastBestj=j;
			}
	}
	*pLastJ=lastBestj;
	return(minDist);
}


// Back track a DP table to find the optimum path
int backTrackDpTable(double **dpTable, int size1, int size2, POSITION **prevPos, int lastI, int lastJ, int *dtwPath){
	int i, pathLen=0, besti, bestj, previ, prevj, temp;
	
	besti=lastI; bestj=lastJ;
	dtwPath[2*pathLen]=besti;
	dtwPath[2*pathLen+1]=bestj;
	pathLen++;
	previ=prevPos[besti][bestj].i; prevj=prevPos[besti][bestj].j;
	while ((previ>=0) && (prevj>=0)){
		besti=previ; bestj=prevj;
		dtwPath[2*pathLen]=besti;
		dtwPath[2*pathLen+1]=bestj;
		pathLen++;
		previ=prevPos[besti][bestj].i; prevj=prevPos[besti][bestj].j;
	}
	// Reverse the stored path to get the correct seqence
	for (i=0; i<pathLen/2; i++){
		temp=dtwPath[2*i]; dtwPath[2*i]=dtwPath[(pathLen-1-i)*2]; dtwPath[(pathLen-1-i)*2]=temp;
		temp=dtwPath[2*i+1]; dtwPath[2*i+1]=dtwPath[(pathLen-1-i)*2+1]; dtwPath[(pathLen-1-i)*2+1]=temp;
	}
	return(pathLen);
}


// Euclidean distance of two vectors
double vecDistance(const double *x, const double *y, int length) {
	int i;
	double sum=0;
	for (i=0; i<length; i++)
		sum += (x[i]-y[i])*(x[i]-y[i]);
	return(sqrt(sum));
}


// DTW1 (27�X-45�X-63�X)
double dtw1totalDist(const double *vec1, int size1, const double *vec2, int size2,
	int featureDim, int beginCorner, int endCorner, double **dtwTable, int needBackTrack, int *dtwPath, int *pdtwPathLen, POSITION **prevPos, double distBound){
	int i, j, lastBestj;
	int lowerBound, lowerBound1, lowerBound2, upperBound, upperBound1, upperBound2;
	double minDist=INF;

	// ====== Return directly if vector lengths differ too much
	if ((double(size1-1)/(size2-1)>2) || ((beginCorner==1) && (endCorner==1) && (double(size2-1)/(size1-1)>2))) {
		*pdtwPathLen=0;
		return(minDist);
	}
	// ====== Initialize dtwTable and prevPos
	for (i=0; i<size1; i++)
		for (j=0; j<size2; j++){
			dtwTable[i][j]=INF;
			if (needBackTrack){prevPos[i][j].i=-1; prevPos[i][j].j=-1;}
		}
	// ====== Construct the first element
	dtwTable[0][0]=vecDistance(vec1, vec2, featureDim);
	if (dtwTable[0][0]>distBound)
		return(minDist);
	// ====== Construct the first column of the DTW table (xy mode)
	if (beginCorner!=1)
		for (j=1; j<=size2-1-ceil((double)(size1-1)/2); j++){
			dtwTable[0][j]=vecDistance(vec1, vec2+j*featureDim, featureDim);
			if (dtwTable[0][j]>distBound)
				return(minDist);
		}
	// ====== Construct all the other columns of the DTW table (xy mode)
	for (i=1; i<size1; i++) {
		lowerBound1=(int)ceil((double)i/2);			// Bound from the start point
		lowerBound2=size2-1-2*(size1-1-i);			// Bound from the end point
		lowerBound=endCorner==1?MAX(lowerBound1, lowerBound2):lowerBound1;
		upperBound1=2*i;					// Bound from the start point
		upperBound2=size2-1-(int)ceil((double)(size1-1-i)/2);	// Bound from the end point
		upperBound=beginCorner==1?MIN(upperBound1, upperBound2):upperBound2;
		for (j=lowerBound; j<=upperBound; j++) {
			dtwTable[i][j] = dtwTable[i-1][j-1];
			if (needBackTrack){prevPos[i][j].i=i-1; prevPos[i][j].j=j-1;}
			// Check horizontal predecessor
			if (i>=2)
				if (dtwTable[i][j]>dtwTable[i-2][j-1]){
					dtwTable[i][j]=dtwTable[i-2][j-1];
					if (needBackTrack){prevPos[i][j].i=i-2; prevPos[i][j].j=j-1;}
				}
			// Check vertical predecessor
			if (j>=2)
				if (dtwTable[i][j]>dtwTable[i-1][j-2]){
					dtwTable[i][j]=dtwTable[i-1][j-2];
					if (needBackTrack){prevPos[i][j].i=i-1; prevPos[i][j].j=j-2;}
				}
			dtwTable[i][j]+=vecDistance(vec1+i*featureDim, vec2+j*featureDim, featureDim);
			if (dtwTable[i][j]>distBound)
				return(minDist);
		}
	}
	// ====== Return the overall minimum distance and the last best position (*pLastJ)
	minDist=findMinDistInDtwTable(dtwTable, size1, size2, endCorner, &lastBestj);
	// ====== Back track to find the optimum path
	if (needBackTrack)
		*pdtwPathLen=backTrackDpTable(dtwTable, size1, size2, prevPos, size1-1, lastBestj, dtwPath);
	return(minDist);
}

void mexFunction(
	int nlhs,	mxArray *plhs[],
	int nrhs, const mxArray *prhs[])
{
	int i, j, size1, size2, beginCorner, endCorner, featureDim, featureDim2, dtwPathLen, needBackTrack, *dtwPath;
	double *vec1, *vec2, **dtwTable, lowerBound;
	POSITION **prevPos;

	// Error checking
	if ((nrhs<2)||(nrhs>5)||(nlhs>3)) {
		char message[200];
		strcpy(message, mexFunctionName());
		strcat(message, " requires 2~5 input arguments and 0~3 output arguments.\n");
		strcat(message, "Usage: [minDistance, dtwPath, dtwTable] = ");
		strcat(message, mexFunctionName());
		strcat(message, "(vec1, vec2, beginCorner, endCorner, lowerBound)");
		mexErrMsgTxt(message);
	}
	featureDim  = mxGetM(VEC1);
	featureDim2 = mxGetM(VEC2);
	if (featureDim!=featureDim2)
		mexErrMsgTxt("Feature dimensions of input vectors mismatch!");
	size1 = mxGetN(VEC1);
	size2 = mxGetN(VEC2);
	if ((size1==0) || (size2==0))
		mexErrMsgTxt("One or two of the input vectors is empty!");

	// Get input arguments (with possible default values)
	vec1 = mxGetPr(VEC1);
	vec2 = mxGetPr(VEC2);
	beginCorner=1;	if (nrhs>=3) beginCorner = (int)(mxGetPr(BEGINCORNER)[0]);
	endCorner=1;	if (nrhs>=4) endCorner = (int)(mxGetPr(ENDCORNER)[0]);
	lowerBound=INF;	if (nrhs>=5) lowerBound=mxGetPr(LOWERBOUND)[0];

	// Create dtwTable & dtwPath
	dtwPathLen=0;	
	dtwTable=(double **)malloc(size1*sizeof(double *));
	for (i=size1-1;i>=0;i--)
		dtwTable[i]=(double *)malloc(size2*sizeof(double));
	needBackTrack=0;
	if (nlhs>1){		// Need to back track to find the optimum path
		needBackTrack=1;
		dtwPath=(int *)malloc(2*(size1+size2)*sizeof(int));	// Max. length of DTW length is (size1+size2);
		prevPos=(POSITION **)malloc(size1*sizeof(POSITION *));
		for (i=size1-1;i>=0;i--)
			prevPos[i]=(POSITION *)malloc(size2*sizeof(POSITION));
	}

	// Create output argument	
	MINDISTANCE = mxCreateDoubleMatrix(1, 1, mxREAL);
	mxGetPr(MINDISTANCE)[0] = dtw1totalDist(vec1, size1, vec2, size2, featureDim, beginCorner, endCorner, dtwTable, needBackTrack, dtwPath, &dtwPathLen, prevPos, lowerBound);
	if (nlhs>1){		// Create output arguments
		DTWPATH = mxCreateDoubleMatrix(2, dtwPathLen, mxREAL);
		for (i=0; i<2*dtwPathLen; i++)
			mxGetPr(DTWPATH)[i] = dtwPath[i]+1;	// Plus one for MATLAB indexing
	}
	if (nlhs>2){
		DTWTABLE = mxCreateDoubleMatrix(size1, size2, mxREAL);
		for (i=0; i<size1; i++)
			for (j=0; j<size2; j++)
				mxGetPr(DTWTABLE)[j*size1+i]=dtwTable[i][j];
		for (i=0; i<size1*size2; i++)
			if (mxGetPr(DTWTABLE)[i]>=INF)
				mxGetPr(DTWTABLE)[i]=mxGetInf();
	}

	// Free memory
	for (i=0; i<size1;i++)
		free(dtwTable[i]);
	free(dtwTable);
	if (nlhs>1){
		for (i=0; i<size1;i++)
			free(prevPos[i]);
		free(prevPos);
		free(dtwPath);
	}
}