gmmTrainMex.cpp is not finished yet.

vqKmeansTest.m has errors.
