clear mex;
addpath ..
%fprintf('Compiling vqKmeansMex.cpp...\n');
%mex vqKmeansMex.cpp d:/users/jang/c/lib/dcpr.cpp d:/users/jang/c/lib/utility.cpp

dim=39;
dataNum=1000;
data = randn(dim, dataNum);
centerNum=64;

fprintf('Test "vqKmeans.m":\n'); tic
[center1, U1, distortion1] = vqKmeans(data, centerNum, 0);
time1=toc; fprintf('Time1 = %.2f sec\n', time1);

fprintf('Test "vqKmeansMex.dll":\n'); tic
[center2, U2, distortion2] = vqKmeansMex(data, centerNum, 1);
time2=toc; fprintf('Time2 = %.2f sec\n', time2);

fprintf('Time ratio = time1/time2 = %f\n', time1/time2);
fprintf('Difference in center = %f\n', sum(sum(abs(center1-center2))));
fprintf('Difference in U = %f\n', sum(sum(abs(U1-U2))));
fprintf('Difference in distortion = %f\n', sum(sum(abs(distortion1-distortion2))));