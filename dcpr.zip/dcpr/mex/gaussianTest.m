addpath ..
clear all;

% Test of gaussianMex and gaussianMex for identity covariance matrix
dim=3;
dataNum=100;
data=randn(dim, dataNum);
gPrm.mu=zeros(dim,1);
gPrm.sigma=rand(dim, 1);
gPrm.sigma=rand(dim, dim);

%mex -Id:/users/jang/c/lib -Id:/users/jang/c/lib/utility -Id:/users/jang/c/lib/dcpr gaussianMex.cpp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/utility/utility.cpp

fprintf('Testing gaussian and gaussianMex:\n');
tic; prob1=gaussian(data, gPrm); time1=toc;
tic; prob2=gaussianMex(data, gPrm); time2=toc;
diff=abs(prob1-prob2);
fprintf('Difference in prob = %g, time1/time2=%f/%f = %f\n', sum(diff), time1, time2, time1/time2);
subplot(2,2,1); plot([prob1; prob2]', '.-');
subplot(2,2,2); plot(diff, '.-');

%mex -Id:/users/jang/c/lib -Id:/users/jang/c/lib/utility -Id:/users/jang/c/lib/dcpr gaussianLogMex.cpp d:/users/jang/c/lib/dcpr/dcpr.cpp d:/users/jang/c/lib/utility/utility.cpp

fprintf('Testing gaussianLog and gaussianLogMex:\n');
tic; logProb1=gaussianLog(data, gPrm); time1=toc;
tic; logProb2=gaussianLogMex(data, gPrm); time2=toc;
diff=abs(logProb1-logProb2);
fprintf('Difference in prob = %g, time1/time2=%f/%f = %f\n', sum(diff), time1, time2, time1/time2);
subplot(2,2,3); plot([logProb1; logProb2]', '.-');
subplot(2,2,4); plot(diff, '.-');