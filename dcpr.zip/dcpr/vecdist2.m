function distmat = vecdist(mat1, mat2, distort)
%VECDIST Distance between two set of vectors
%	VECDIST(MAT1, MAT2) returns the distance matrix between two set
%	of vectors MAT1 and MAT2. The element at row i and column j of
%	the return matrix is the Euclidean distance between row i of
%	MAT1 and row j of MAT2.

%	VECDIST(MAT1, MAT2, DISTORT) uses DISTORT to calculate the
%	distance:
%	dist = sqrt(sum(((V1-V2).*DISTORT).^2))

%	Roger Jang, Sept-24-1996, March-31-1997.

if nargin < 3,
	distort = ones(size(mat1,2), 1);
end
if nargin < 2,
	mat2 = mat1;
end
if nargin < 1,
	error('VECDIST needs at least one input argument!');
end

[m1, n1] = size(mat1);
[m2, n2] = size(mat2);

if n1 ~= n2,
	error('Matrices mismatch!');
end

distmat = zeros(m1, m2);

if n1 == 1,
	distmat = abs((mat1*ones(1,m2)-ones(m1,1)*mat2')*diag(distort));
elseif m2 >= m1,
	for i = 1:m1,
		distmat(i,:) = ...
			sqrt(sum((((ones(m2,1)*mat1(i,:)-mat2)*diag(distort))').^2));
	end
else 
	for i = 1:m2,
		distmat(:,i) = ...
			sqrt(sum((((mat1-ones(m1,1)*mat2(i,:))*diag(distort))').^2))';
	end
end
