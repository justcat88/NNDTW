function [gmmData, recogRate1, recogRate2, validGaussianNumIndex]=gmmTrainEvalWrtGaussianNum(DS, TS, vecOfGaussianNum, covType, gmmTrainParam)
% gmmTrainEvalWrtGaussianNum: GMM training and test, w.r.t. varying number of mixtures
%	Usage: [gmmData, recogRate1, recogRate2, validGaussianNumIndex]=gmmTrainEvalWrtGaussianNum(DS, TS, vecOfGaussianNum, trainParam, covType, gmmTrainParam)
%		DS: training set
%		TS: test set
%		vecOfGaussianNum: vector of numbers of Gaussian components
%		covType: type of covariance matrix, 1: identity times a constant, 2: diagonal, 3: full
%		gmmTrainParam: parameter for training GMM
%		gmmData: GMM parameters
%			gmmData(i): in which each gmm has vecOfGaussianNum(i) gaussians
%			gmmData(i).gmm(j): gmm of class j at case i
%			gmmData(i).gmm(j).gmmParam(k): gaussian k of class j at case i
%			gmmData(i).gmm(j).gmmParam(k).mu: mean vector
%			gmmData(i).gmm(j).gmmParam(k).sigma: covariance matrix
%			gmmData(i).gmm(j).gmmParam(k).w: weight
%		recogRate1: inside-test recognition rate
%		recogRate2: outside-test recognition rate
%		validGaussianNumIndex: Actually valid index for vecOfGaussianNum. We need to have this output parameters since
%			sometimes we are given a large number of mixtures which cannot be used for GMM training at all
%
%	For example:
%		[DS, TS]=prData('wine');
%		vecOfGaussianNum=2:30;
%		covType=1;
%		gmmTrainParam=gmmTrainParamSet;
%		gmmTrainParam.plotOpt=1;
%		[gmmData, recogRate1, recogRate2, validGaussianNumIndex]=gmmTrainEvalWrtGaussianNum(DS, TS, vecOfGaussianNum, covType, gmmTrainParam);

%	Roger Jang, 20070516

if nargin<1, selfdemo; return; end
if nargin<4, gmmTrainParam=gmmTrainParamSet; end

classLabel=unique(DS.output);
classNum=length(classLabel);
recogRate1=zeros(length(vecOfGaussianNum), 1);
recogRate2=zeros(length(vecOfGaussianNum), 1);
[dim, dsNum]=size(DS.input);
[dim, tsNum]=size(TS.input);
fprintf('DS data count = %d, TS data count = %d\n', dsNum, tsNum);
classSizeDS=classDataCount(DS); fprintf('DS class data count = %s\n', mat2str(classSizeDS));
classSizeTS=classDataCount(TS); fprintf('TS class data count = %s\n', mat2str(classSizeTS));

% ====== Perform training and compute recognition rates
errorGaussianNumIndex=0;
errorClassIndex=0;
%h=waitbar(0, 'Please wait...');
for j=1:length(vecOfGaussianNum)
	fprintf('%d/%d: No. of Gaussian = %d ===> ', j, length(vecOfGaussianNum), vecOfGaussianNum(j));
	% ====== Training GMM model for each class
	for i=1:classNum
	%	fprintf(' class %d... ', i);
		index=find(DS.output==classLabel(i));
		theData=DS.input(:, index);
		try
	%		gmmTrainParam.dispOpt=1;
			[gmmData(j).gmm(i).gmmParam, gmmData(j).gmm(i).logProb] = gmmTrain(theData, [vecOfGaussianNum(j), covType], gmmTrainParam);
		catch
			errorClassIndex=i;
			break;
		end
	end
	if errorClassIndex>0
		errorGaussianNumIndex=vecOfGaussianNum(j);
		fprintf('Error out on errorGaussianNumIndex=%d and errorClassIndex=%i\n', errorGaussianNumIndex, errorClassIndex);
		break;
	end
	% ====== Compute inside-test recognition rate
%	outProb=zeros(classNum, dsNum);
%	for i=1:classNum
%		outProb(i,:)=gmmEval(DS.input, gmmData(j).gmm(i).gmmParam);
%	end
%	[maxValue, computedClassIndex]=max(outProb);
	computedClassIndex = gmmClassifierEval(DS.input, gmmData(j), classSizeDS);
	recogRate1(j)=sum(DS.output==computedClassIndex)/length(DS.output);
%	clear outProb computedClassIndex
	% ====== Compute outside-test recognition rate
%	outProb=zeros(classNum, tsNum);;
%	for i=1:classNum
%		outProb(i,:)=gmmEval(TS.input, gmmData(j).gmm(i).gmmParam);
%	end
%	[maxValue, computedClassIndex]=max(outProb);
	computedClassIndex = gmmClassifierEval(TS.input, gmmData(j), classSizeDS);
	recogRate2(j)=sum(TS.output==computedClassIndex)/length(TS.output);
%	clear outProb computedClassIndex
	% ====== Printing
	fprintf('inside RR = %g%%, outside RR = %g%%\n', recogRate1(j)*100, recogRate2(j)*100);
%	waitbar(j/length(vecOfGaussianNum), h);
end
%close(h);

if errorGaussianNumIndex>0
	gmmData(errorGaussianNumIndex:end)=[];
	recogRate1(errorGaussianNumIndex:end)=[];
	recogRate2(errorGaussianNumIndex:end)=[];
	vecOfGaussianNum(errorGaussianNumIndex:end)=[];
end
validGaussianNumIndex=errorGaussianNumIndex-1;

% ====== Plot the result
if gmmTrainParam.plotOpt
	plot(vecOfGaussianNum, recogRate1*100, 'o-', vecOfGaussianNum, recogRate2*100, 'square-'); grid on
	legend('Inside test', 'Outside test', 4);
	xlabel('No. of Gaussian mixtures'); ylabel('Recognition Rates (%)');
end

% ====== Self demo
function selfdemo
[DS, TS]=prData('wine');
vecOfGaussianNum=2:30;
covType=1;
gmmTrainParam=gmmTrainParamSet;
gmmTrainParam.plotOpt=1;
[gmmData, recogRate1, recogRate2, validGaussianNumIndex]=feval(mfilename, DS, TS, vecOfGaussianNum, covType, gmmTrainParam);