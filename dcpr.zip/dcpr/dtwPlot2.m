function dtwplot2(vec1, vec2, dtwPath) 
% dtwPlot2: Plot the result of DTW of two pitch/MFCC vectors
%	Usage: dtwplot2(vec1, vec2, DTWpath)
%
%	For example:
%		vec1=[71 73 75 80 80 80 78 76 75 73 71 71 71 73 75 76 76 68 76 76 75 73 71 70 70 69 68 68 72 74 78 79 80 80 78];
%		vec2=[69 69 73 75 79 80 79 78 76 73 72 71 70 70 69 69 69 71 73 75 76 76 76 76 76 75 73 71 70 70 71 73 75 80 80 80 78];
%		[minDist1, dtwPath1, dtwTable1] = dtw1(vec1, vec2);
%		[minDist2, dtwPath2, dtwTable2] = dtw2(vec1, vec2);
%		subplot(2,1,1); dtwplot2(vec1, vec2, dtwPath1); title('DTW alignment by dtw1');
%		subplot(2,1,2); dtwplot2(vec1, vec2, dtwPath2); title('DTW alignment by dtw2');

%	Roger Jang, 20030521, 20070522

if nargin<1; selfdemo; return; end

if size(vec1,1)>1 | size(vec2,1)>1,	% Inputs are MFCC matrices for ASR
	vec1=zeros(1, size(vec1,2));
	vec2=zeros(1, size(vec2,2));
end

initShift=dtwPath(2,1)-dtwPath(1,1);		% �Y�D�q�Y���A�evec1�ɡA�ݥ������I��
plot((1:length(vec1))+initShift, vec1, '.-');
gap=(max(vec1)-min(vec1)+max(vec2)-min(vec2))/4;	% �W�U�i�Ϊ��t�Z
newVec2=vec2-min(vec2)+max(vec1)+gap;
line(1:length(newVec2), newVec2, 'marker', '.', 'color', 'k');
legend('vec1', 'vec2');

for i=1:size(dtwPath, 2)
	from=[dtwPath(1,i)+initShift, vec1(dtwPath(1,i))];
	to  =[dtwPath(2,i), newVec2(dtwPath(2,i))];
	line([from(1), to(1)], [from(2), to(2)], 'color', 'r');
end

axisLimit=axis;
line(axisLimit(1:2), min(vec1)*[1 1], 'color', 'k', 'linestyle', ':');
line(axisLimit(1:2), max(vec1)*[1 1], 'color', 'k', 'linestyle', ':');
line(axisLimit(1:2), min(newVec2)*[1 1], 'color', 'k', 'linestyle', ':');
line(axisLimit(1:2), max(newVec2)*[1 1], 'color', 'k', 'linestyle', ':');
axis tight

% ====== Self demo
function selfdemo
% Generate data for DTW
dataNum = 101;
t = linspace(0,1,dataNum);
y = sin(50*t);
new_t = smf(t, [0,1]);
new_y = interp1(new_t, y, t, 'cubic');	% Resampling
% ====== Delete some points
%deleteNum = 5;
%y(1:deleteNum)=[];
%y(end-deleteNum+1:end)=[];
[minDist, dtwPath]=dtw1(y, new_y, 1, 1, 0);
subplot(2,1,1); feval(mfilename, y, new_y, dtwPath); title('DTW alignment using dtw1');
[minDist, dtwPath]=dtw2(y, new_y, 1, 1, 0);
subplot(2,1,2); feval(mfilename, y, new_y, dtwPath); title('DTW alignment using dtw2');