% Using IRIS data to test looknn.m
load iris.dat
input=iris(:, 1:end-1);
sampleNum=size(iris, 1);
	distmat = vecdist(input);
	distmat(1:(sampleNum+1):sampleNum^2) = inf;	% Set diagonal elements to inf
k=1;
[misclassify, index, nearestSampleIndex] = looknn(iris, k, 0);

table=[index, iris(index, end), nearestSampleIndex, iris(nearestSampleIndex, end)]
fprintf('column 1: index of misclassified sample\n');
fprintf('column 2: class of misclassified sample\n');
fprintf('column 3: index of nearest neighbor of the misclassified sample\n');
fprintf('column 4: class of nearest neighbor of the misclassified sample\n');
