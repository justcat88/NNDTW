addpath ..

fprintf('Traing GMM...\n');
DS=prData('iris');
gaussianNum=8;
covType=2;
gmmParam=gmmTrain(DS.input, [gaussianNum, covType]);
dataNum=10000;
dim=length(gmmParam(1).mu);
data=100*rand(dim, dataNum);

fprintf('Testing gmmEval.m...\n');
chunkSize=1;
tic, [logProb1, eachProb1]=gmmEval(data, gmmParam, chunkSize); time1=toc;
fprintf('time1 (chunkSize=%d) = %g\n', chunkSize, time1);
chunkSize=10;
tic, [logProb2, eachProb2]=gmmEval(data, gmmParam, chunkSize); time2=toc;
fprintf('time2 (chunkSize=%d) = %g\n', chunkSize, time2);
chunkSize=100;
tic, [logProb2, eachProb2]=gmmEval(data, gmmParam, chunkSize); time3=toc;
fprintf('time3 (chunkSize=%d) = %g\n', chunkSize, time3);
chunkSize=1000;
tic, [logProb2, eachProb2]=gmmEval(data, gmmParam, chunkSize); time4=toc;
fprintf('time4 (chunkSize=%d) = %g\n', chunkSize, time4);


fprintf('time1/time2=%g/%g=%g\n', time1, time2, time1/time2);
fprintf('time1/time3=%g/%g=%g\n', time1, time3, time1/time3);
fprintf('time1/time4=%g/%g=%g\n', time1, time4, time1/time4);

fprintf('Difference in logProb1 and logProb2 = %g\n', sum(abs(logProb1-logProb2)));
fprintf('Difference in eachProb1 and eachProb2 = %g\n', sum(sum(abs(eachProb1-eachProb2))));