if 0
load table;
data_n=size(a,1);
cluster_n=3;
a=(a+a')/2;
tic;
[center,U]=kmeans2mex(a,cluster_n);
toc;
center
else
data_n=400;
cluster_n=3;
data1 = ones(data_n, 1)*[0 0] + randn(data_n, 2)/5;
data2 = ones(data_n, 1)*[0 1] + randn(data_n, 2)/5;
data3 = ones(data_n, 1)*[1 0] + randn(data_n, 2)/5;
xy = [data1; data2; data3];
for i=1:data_n,
	r=round(rand*3);
	if r==1
		xy(i,:)=[-1 -1];
	elseif r==2
		xy(i,:)=[1 -1];
	else
		xy(i,:)=[0 1];
	end
	xy(i,:)=xy(i,:)*2+[randn randn];
end
for i=1:data_n,
	for j=1:data_n,
		dist(i,j)=norm(xy(i,:)-xy(j,:));
	end
end
c=['y' 'c' 'b' 'g'];
tic; [center,U]=kmeans2(dist,cluster_n); toc;
tic; [center,U]=kmeans2mex(dist,cluster_n); toc;
hold on;
for i=1:cluster_n,
	j=find(U(i,:));
	plot(xy(j,1),xy(j,2),[c(i) '.']);
end
plot(xy(center,1),xy(center,2),'ro');
hold off;
end
