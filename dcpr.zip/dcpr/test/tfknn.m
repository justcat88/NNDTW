load iris.dat

sampleData = iris;
train = iris(1:2:end, :);	% Use odd-indexed data as the sample data
test =   iris(2:2:end, :);	% Use even-indexed data as the test data

k = 3;
sampleIn = train(:, 1:end-1);
sampleOut = initfknn(train, k); 
testFuzzyOut = fknn(sampleIn, sampleOut, test(:, 1:end-1), k);
[junk, testCrispOut] = max(testFuzzyOut'); 
misclassified_n = sum(testCrispOut'~=test(:, end));
dispconf(testCrispOut, test(:,end));

fprintf('\nResults of using fuzzy k-nearest neighbor rule for IRIS data:\n');
fprintf('Sample data: Odd-indexed data\n');
fprintf('Test data: Even-indexed data\n');
fprintf('No. of misclassified case is %g.\n', misclassified_n);
fprintf('Recognition rate = %g/%g = %.2f%%\n', ...
	misclassified_n, size(test,1), 100*misclassified_n/size(test, 1));

for k = 3:9,
	fprintf('k = %g\n', k);
	% ====== Leave-one-out test
	sampleNum = size(sampleData,1);
	correct = zeros(sampleNum, 1);
	for i=1:length(sampleData),
	%	fprintf('%g/%g\n', i, sampleNum);
		test = sampleData(i,:);
		train = sampleData;
		train(i,:) = [];
		trainIn = train(:, 1:end-1);
		trainOut = initfknn(train, k);
		testOut = fknn(trainIn, trainOut, test(1:end-1), k);
		[junk, index] = max(testOut);
		correct(i) = index==test(end);
	end
	fprintf('No. of misclassification: %g\n', sum(correct==0));
	fprintf('Leave-one-out recognition rate = %g%%\n', sum(correct)/length(correct)*100);
end
