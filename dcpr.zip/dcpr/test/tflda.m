%load abalone.dat; data = abalone;
%load iris.dat; data = iris;

%load wine.dat; data=[wine(:,2:end) wine(:,1)];
load wine.dat; data=[normal(wine(:,2:end)) wine(:,1)];

k = 3;
sampleIn = data(:, 1:end-1);
sampleOut = data(:, end);
sampleFuzzyOut = initfknn(data, k);

data_n = size(sampleIn,1);
dim_n = size(sampleIn,2);

fprintf('Leave-one-out analysis:\n');
fprintf('\tFull data:\n');
wrong = looknn(data); 
correct = size(data, 1) - wrong;
fprintf('\t\tLOO error count = %g\n', wrong);
fprintf('\t\tRecognition rate = %g/%g = %5.2f%%\n', correct, data_n,...
	correct/data_n*100);

recog = zeros(dim_n, 1);
newSampleIn = flda(sampleIn, sampleFuzzyOut);
for i = dim_n:-1:1,
	fprintf('\tPartial data after LDA (dimension = %g):\n', i);
	wrong = looknn([newSampleIn(:, 1:i) sampleOut]); 
	correct = size(data, 1) - wrong;
	recog(i) = correct/data_n*100;
	fprintf('\t\tLOO error count = %g\n', wrong);
	fprintf('\t\tRecognition rate = %g/%g = %5.2f%%\n', correct, ...
		data_n, recog(i));
end
figure
plot(1:dim_n, recog, '-o');
xlabel('Dimensions used in fuzzy LDA');
ylabel('Leave-one-out recognition rates');
