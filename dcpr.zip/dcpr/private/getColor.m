function color=getColor(index, useVec)
% getColor: Get color from a rotating palette
%	Usage: color=getColor(index)
%
%	For example:
%		for i=1:6
%			line(1:10, rand(1, 10), 'color', getColor(i), 'lineWidth', 3);
%		end
%		legend('Color 1', 'Color 2', 'Color 3', 'Color 4', 'Color 5', 'Color 6');

% Roger Jang, 20040910, 20071009

if nargin<1, index=1; end
if nargin<2, useVec=0; end

if ~useVec
	allColor={'b', 'r', 'g', 'm', 'c', 'y'};
	color=allColor{mod(index-1, length(allColor))+1};
else
	allColor=[0 0 1; 1 0 0; 0 1 0; 1 0 1; 0 1 1; 1 1 0];
	color=allColor(mod(index-1, length(allColor))+1, :);
end
