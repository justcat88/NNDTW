function computedClassIndex = gmmClassifierEval(data, gmmSet, priors, chunkSize);
% gmmClassifierEval: Evaluation of a GMM classifier with a given vector of priors
%	Usage: computedClassIndex = gmmClassifierEval(data, gmmSet);
%		data: dim x dataNum matrix where each column is a data point
%		gmmSet.gmm(i): Parameters for class i, which is modeled as a GMM
%			gmmSet.gmm(i).gmmParam(j).mu: a mean vector of dim x 1 for Gaussian component j
%			gmmSet.gmm(i).gmmParam(j).sigma: a covariance matrix for Gaussian component j
%			gmmSet.gmm(i).gmmParam(j).w: a weighting factor for Gaussian component j
%		priors: Vector of priors, or simply the vector holding no. of entries in each class
%			(To obtain the class sizes, you can use "classSize".
%		chunkSize: size of a chunk for vectorization
%			1 for fully for-loop version
%			inf for fully vectorized version (which could cause "out of memory" is data size is large)

%	Roger Jang, 20090123, 20090303

classNum=length(gmmSet.gmm);
dataNum=size(data, 2);
if nargin<3, priors=ones(classNum, 1); end
if nargin<4, chunkSize=10000; end

priorLogProb=log(priors/sum(priors));

% ====== Fully vectorized version, which is likely to be out of memory
%outputLogProb=zeros(classNum, dataNum);		% This is memory hog, especially when classNum is big (in speaker id, for example)!!!
%for i=1:classNum
%	outputLogProb(i,:)=gmmEval(data, gmmSet.gmm(i).gmmParam)+priorLogProb(i);
%end
%[maxValue, computedClassIndex]=max(outputLogProb);

% ====== Partial vectorized version, which operates with a chunk of 10000 entries of data at a time to avoid "out of memory" error.
chunkNum=ceil(dataNum/chunkSize);
if chunkNum==0, chunkNum=1; end		% This happens when chunkSize=inf
computedClassIndex=zeros(1, dataNum);
for j=1:chunkNum
	rangeIndex=((j-1)*chunkSize+1):min(j*chunkSize, dataNum);
	outputLogProb=zeros(classNum, length(rangeIndex));
	for i=1:classNum
 		outputLogProb(i,:)=gmmEval(data(:, rangeIndex), gmmSet.gmm(i).gmmParam)+priorLogProb(i);
	end
	[maxValue, computedClassIndex(rangeIndex)]=max(outputLogProb);
end