function gmmParam=gmmGrow(gmmParam, targetGaussianNum)
% gmmGrow: Grow gaussians within a GMM 
%	Usage: gmmParam=gmmGrow(gmmParam, targetGaussianNum)
%
%	For example, please refer to gmmGrowDemo.m

%	Roger Jang, 20080727

if nargin<1, selfdemo; return; end

gaussianNum=length(gmmParam);
if targetGaussianNum>2*gaussianNum
	error('Growth too fast!');
end

dim=length(gmmParam(1).mu);
index=randperm(gaussianNum);
for i=1:targetGaussianNum-gaussianNum
	% To clone a gaussian, weight is lowered first
	gmmParam(index(i)).w=gmmParam(index(i)).w/2;
	% Start clone
	gmmParam(end+1)=gmmParam(index(i));
	% Find sigma to guide the center splitting
	sigma=gmmParam(end).sigma;
	if length(sigma)==1, sigma=sigma*eye(dim); end
	if prod(size(sigma))==dim*dim, sigma=diag(sigma); end
	% Center splitting
	gmmParam(end).mu=gmmParam(end).mu+randn(dim, 1).*sigma;
end

% ====== Self demo
function selfdemo
gmmGrowDemo;