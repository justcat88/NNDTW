userData=get(gcf, 'userdata');
inData=userData.inData;
pointLabel=userData.pointLabel;
circleH=userData.circleH;
textH=userData.textH;

temp = get(gca, 'CurrentPoint');
pos(1,1) = temp(1,1);
pos(2,1) = temp(1,2);
xlim=get(gca, 'xlim');
ylim=get(gca, 'ylim');
if (xlim(1)<=pos(1) & pos(1)<=xlim(2) & ylim(1)<=pos(2) & pos(2)<=ylim(2))
	distance=pairwiseSqrDistance(pos, inData(1:2, :));
	[minValue, minIndex]=min(distance);
	set(circleH, 'xdata', inData(1, minIndex), 'ydata', inData(2, minIndex));
	set(textH, 'string', pointLabel{minIndex}, 'position', [inData(1:2, minIndex); 0]');
end