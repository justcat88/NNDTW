function [computedClass, recogRate, hitIndex]=qcEval(DS, classParam, plotOpt)
% qcTrain: Evaluation for the quadratic classifier
%	Usage: [computedClass, recogRate, hitIndex]=qcEval(DS, classParam, plotOpt)
%		If DS does not have "output" field, then this command won't return "recogRate" and "hitIndex".

% Roger Jang, 20041123, 20080924

if nargin<1, selfdemo; return; end
if nargin<2, classParam=[]; end
if nargin<3, plotOpt=0; end

classNum=length(classParam);
[dim, dataNum]=size(DS.input);
logProb=zeros(classNum, dataNum);
for i=1:classNum
	dataMinusMu = DS.input-classParam(i).mu*ones(1, dataNum);
	logProb(i,:) = -0.5*sum(dataMinusMu.*(classParam(i).invSigma*dataMinusMu), 1)+classParam(i).gconst;
	logProb(i,:) = logProb(i,:)+log(classParam(i).weight);		% Take weight into consideration
end
[junk, computedClassIndex]=max(logProb);
className=[classParam.name];
computedClass=className(computedClassIndex);
if isfield(DS, 'output')
	className=[classParam.name];
	hitIndex=find(computedClass==DS.output);
	recogRate = length(hitIndex)/dataNum;
end

if plotOpt & dim==2
	dcprDataPlot(DS);
	axis image; box on
	missIndex=1:dataNum;
	missIndex(hitIndex)=[];
	% display these points
	for i=1:length(missIndex),
		line(DS.input(1,missIndex(i)), DS.input(2,missIndex(i)), 'marker', 'x', 'color', 'k');
	end
	titleString = sprintf('%d error points denoted by "x".', length(missIndex));
	title(titleString);
end

% ====== Self demo
function selfdemo
[DS, TS]=prData('iris');
DS.input=DS.input(3:4, :);
TS.input=TS.input(3:4, :);
[classParam, recogRate1]=qcTrain(DS);
[computedClass, recogRate2, hitIndex]=qcEval(TS, classParam, 1);
fprintf('Inside recog rate = %g%%\n', recogRate1*100);
fprintf('Outside recog rate = %g%%\n', recogRate2*100);