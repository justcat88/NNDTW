function coef=linClassifier(DS, trainParam, plotOpt)
% linClassifier: Linear classifier (Perceptron) using on-line learning
%
%	Type "linClassifier" for a demo.

% Roger Jang, 20040910 

if nargin<1, selfdemo; return; end
if nargin<2 | isempty(trainParam),
	trainParam.eta=0.0002;
	trainParam.maxIter=3000;
end
if nargin<3, plotOpt=0; end

[dim, dataNum]=size(DS.input);

if plotOpt==1 & dim==2,
	dcprDataPlot(DS);
	axis image
	lineH = line([-1 1], [-1 1], 'linewidth', 2, 'erase', 'xor', 'color', 'm');
	r = 0.1;
	theta = linspace(0, 2*pi);
	circleX = r*cos(theta); 
	circleY = r*sin(theta); 
	circleH = line(nan, nan, 'color', 'k', 'erase', 'xor');
end

uniqueOutput=unique(DS.output);
if length(uniqueOutput)~=2, error('Must be 2-class problem!'); end
% �N DS.output �令 -1 �� 1
index=find(DS.output==max(uniqueOutput));
DS.output=-ones(1, size(DS.output,2));
DS.output(index)=1;

% The main loop
coef=randn(dim+1,1);

for i=1:trainParam.maxIter
	picked = ceil(rand*dataNum);
	input = DS.input(:, picked);
	target = DS.output(:, picked);
	computed = sign(dot(coef, [input; 1]));
	coef=coef+trainParam.eta*(target-computed)*[input; 1];
	if plotOpt==1 & dim==2,
		set(circleH, 'xdata', circleX+DS.input(1, picked), 'ydata', circleY+DS.input(2, picked));
		set(lineH, 'ydata', [coef(1)-coef(3), -coef(1)-coef(3)]/coef(2));
		fprintf('iteration = %d\n', i);
		drawnow
	end
end

% ====== Self demo
function coef=selfdemo

dataNum = 2000;
DS.input = rand(2, dataNum)*2-1;
DS.output = -ones(1, dataNum);
index = find(DS.input(1, :)+DS.input(2, :)>0);
DS.output(index)=1;
plotOpt=1;
coef=feval(mfilename, DS, [], plotOpt);
