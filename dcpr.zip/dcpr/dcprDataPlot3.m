function dcprDataPlot3(DS, plotTitle, displayAnnotation)
% dcprDataPlot: Plot of 3D data for data clustering or pattern recognition
%	Usage: dcprDataPlot3(DS, plotTitle, inputName, pointLabel)
%		DS: data to be displayed
%			DS.input: input part
%			DS.output: output part (this part could be missing for DC)
%			DS.dataName: data name (or description)
%			DS.inputName: data input name
%			DS.annotation: data annotation for each data point 

% Roger Jang, 20060507

if nargin<1, selfdemo; return; end
[dim, dataNum]=size(DS.input);
if dim<3, return; end
if nargin<2, plotTitle=''; end
if nargin<3, displayAnnotation=1; end

if ~isfield(DS, 'dataName'), DS.dataName=''; end
if ~isfield(DS, 'inputName'), for i=1:dim, DS.inputName{i}=['Input ', int2str(i)]; end, end
if ~isfield(DS, 'annotation'), for i=1:dataNum, DS.annotation{i}=int2str(i); end, end

markerSize=5;
if isfield(DS, 'output')
	DS.output=classOutputConvert(DS.output);	% Convert the output to be intergers from 1 to classNum
	classNum=length(unique(DS.output));
	for i=1:classNum
		index=find(DS.output==i);
		xData=DS.input(1, index);
		yData=DS.input(2, index);
		zData=DS.input(3, index);
		line(xData, yData, zData, 'marker', '.', 'lineStyle', 'none', 'color', getColor(i));
	end
else
	xData=DS.input(1, :);
	yData=DS.input(2, :);
	zData=DS.input(3, :);
	line(xData, yData, zData, 'marker', '.', 'lineStyle', 'none', 'color', getColor(1));
end

box on
xlabel(DS.inputName{1});
ylabel(DS.inputName{2});
zlabel(DS.inputName{3});
title(DS.dataName);
axis image
rotate3d on
view(-37.5, 30);

% ====== Self demo
function selfdemo
DS=prData('random3');
feval(mfilename, DS);