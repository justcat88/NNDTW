function hClusteringDemo(pattern_mat, distance, level)
% LINKCLU Display the formation of hierarchical clustering step by step
%
%	Usage: hClusteringDemo(pattern_mat, distance, level)
%	pattern_mat: pattern matrix
%	distance: distance matrix of the pattern matrix
%	level: hierarchical clustering result of the patern matrix
%
%	Type "hclustdm" to see a demo of a step-by-step hierarchical clustering
%	(single-linkage) of 50 random patterns of dimensionality 2.
%
%	See also AGGCLUST, DENDRO.

%	Roger Jang, 19981027

% Demo when no input arguments
if nargin == 0, selfdemo; return, end

plot(pattern_mat(:, 1), pattern_mat(:, 2), 'bo');
axis equal;
axis square;
dataNum = size(pattern_mat, 1);
for i = 2:dataNum,
	if i>=3, set(h, 'color', 'k'); end
	[m, n] = find(distance==level(i).height);
	h = line(pattern_mat(m,1), pattern_mat(m,2), 'color', 'r', 'linewidth', 3, 'erase', 'none');
	drawnow;
%	fprintf('Press any key to form %g clusters ...\n', dataNum-i+1); pause;
	pause(0.2);
end

% ====== Self demo ======
function selfdemo
dataNum = 50;
dimension = 2;
points = rand(dataNum, dimension);

% ====== data from fcmdemo.m
        k = 10;
        c1 = [0.125 0.25];
        data1 = randn(dataNum, 2)/k + ones(dataNum, 1)*c1;
        c2 = [0.625 0.25];
        data2 = randn(dataNum, 2)/k + ones(dataNum, 1)*c2;
        c3 = [0.375 0.75];
        data3 = randn(dataNum, 2)/k + ones(dataNum, 1)*c3;
        c4 = [0.875 0.75];
        data4 = randn(dataNum, 2)/k + ones(dataNum, 1)*c4;
        data = [data1; data2; data3; data4];
        index = (min(data')>0) & (max(data')<1);
        data(find(index == 0), :) = [];
	points = data;
	dataNum = size(points,1);


for i = 1:dataNum,
	for j = 1:dataNum,
		distance(i, j) = norm(points(i,:)-points(j,:));
	end
end

% Diagonal elements should always be inf.
for i = 1:dataNum, distance(i, i) = inf; end

method = 'single';
%method = 'complete';
level = aggclust(distance, method);

% Plot heights w.r.t. levels
%figure;
%plot([level.height], 'r:o');
%xlabel('Level');
%ylabel('Height');
%title('Height vs. level');

% Plot the dendrogram
figure;
dendro(level);

figure;
plot([level.height], 'r:o');
xlabel('Level');
ylabel('Height');
title('Height vs. level');

% View the formation of clusters
figure;
title('Press any key to link clusters.');
feval(mfilename, points, distance, level);
title('The whole data set has been linked to a single cluster!');