function plotClassVsFeature(DS)
%plotClassVsFeature: Plot of class vs. feature

%	Roger Jang, 20041209

if nargin == 0, selfdemo; return, end

[featureNum, dataNum]=size(DS.input);
distinctClass = elementCount(DS.output);
classNum = length(distinctClass);
plotNum = featureNum;
side = ceil(sqrt(plotNum));
k = 1;
for i=1:side,
	for j=1:side,
		if k<=plotNum,
			subplot(side, side, k);
			for p = 1:classNum
				index = find(DS.output==distinctClass(p));
				plot(DS.input(k, index), DS.output(index), ['.', getColor(p)]);
				if p==1, hold on; end
			end
			hold off;
			axis([-inf inf -inf inf]);
			if isfield(DS, 'inputName')
				xlabel(['x', num2str(k), ': ', DS.inputName{k}]);
			else
				xlabel(['x', num2str(k)]);
			end
			ylabel('Class');
			k = k+1;
		end
	end
end

% ====== Self demo
function selfdemo
DS=prData('iris');
feval(mfilename, DS);