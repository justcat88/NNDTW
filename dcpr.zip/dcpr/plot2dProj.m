function plot2dProj(DS)
%plotClassVsFeature: Plot of class vs. feature

%	Roger Jang, 20041209

if nargin == 0, selfdemo; return, end

[featureNum, dataNum]=size(DS.input);
distinctClass = elementCount(DS.output);
classNum = length(distinctClass);
sequence = combine(1:featureNum, 2);
plotNum = size(sequence,1);
side = ceil(sqrt(plotNum));
k = 1;
for i = 1:side,
	for j = 1:side,
		if k <= plotNum,
			subplot(side, side, k);
			for p=1:classNum
				index=find(DS.output==distinctClass(p));
				line(DS.input(sequence(k,1), index), DS.input(sequence(k,2), index), 'marker', '.', 'lineStyle', 'none', 'color', getColor(p));
			end
			box on; axis([-inf inf -inf inf]); axis image;
			if isfield(DS, 'inputName')
				xlabel(['x', num2str(sequence(k,1)), ': ', DS.inputName{sequence(k,1)}]);
				ylabel(['x', num2str(sequence(k,2)), ': ', DS.inputName{sequence(k,2)}]);
			else
				xlabel(['x', num2str(sequence(k,1))]);
				ylabel(['x', num2str(sequence(k,2))]);
			end
%			fileName=sprintf('LED%d_%d', sequence(k,1), sequence(k,2));
%			eval(['print -dpng ', fileName]);
			k = k+1;
		end
	end
end

% ====== Self demo
function selfdemo
DS=prData('iris');
feval(mfilename, DS);