function gmmTrainParam=gmmTrainParamSet

% The following parameters are used for gmmTrain()
gmmTrainParam.dispOpt=0;		% Display info during training
gmmTrainParam.plotOpt=0;		% Display rr with respect to mix numbers
gmmTrainParam.useKmeans=1;		% Use kmeans to find the initial centers
gmmTrainParam.maxIteration=20;		% Max. iteration
gmmTrainParam.minImprove=eps;		% Min. improvement
gmmTrainParam.minVariance=eps;		% Min. variance

% The following parameters are used for gmmTrainEvalWrtGaussianNum()
gmmTrainParam.useCenterSplitting=0;	% Use center splitting (Only if the no. of gaussians increases by the power of 2.)