% Example of using gmmGrow.m for growing a GMM (gaussian mixture models).

DS = dcData(2);
data=DS.input;
gaussianNum=1;
covType=3;
gmmTrainParam=gmmTrainParamSet;
gmmTrainParam.useKmeans=1;
gmmTrainParam.dispOpt=1;
gmmTrainParam.maxIteration=500;

for i=1:5
	close all;
	[gmmParam, lp] = gmmTrain(data, [gaussianNum, covType], gmmTrainParam);
	gaussianNum=2*gaussianNum;
	gmmParam = gmmGrow(gmmParam, gaussianNum);
end

pointNum = 40;
x = linspace(min(data(1,:)), max(data(1,:)), pointNum);
y = linspace(min(data(2,:)), max(data(2,:)), pointNum);
[xx, yy] = meshgrid(x, y);
data = [xx(:) yy(:)]';
z = gmmEval(data, gmmParam);
zz = reshape(z, pointNum, pointNum);
figure; mesh(xx, yy, zz); axis tight; box on; rotate3d on
figure; contour(xx, yy, zz, 30); axis image