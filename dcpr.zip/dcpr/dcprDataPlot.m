function dcprDataPlot(DS, plotTitle, displayAnnotation)
% dcprDataPlot: Plot of 2D data for data clustering or pattern recognition
%	Usage: dcprDataPlot(DS, plotTitle, inputName, pointLabel)
%		DS: data to be displayed
%			DS.input: input part
%			DS.output: output part (this part could be missing for DC)
%			DS.dataName: data name (or description)
%			DS.inputName: data input name
%			DS.annotation: data annotation for each data point 

% Roger Jang, 20040910

if nargin<1, selfdemo; return; end
[dim, dataNum]=size(DS.input);
if dim<2, return; end
if nargin<2, plotTitle=''; end
if nargin<3, displayAnnotation=1; end

if ~isfield(DS, 'dataName'), DS.dataName=''; end
if ~isfield(DS, 'inputName'), for i=1:dim, DS.inputName{i}=['Input ', int2str(i)]; end, end
if ~isfield(DS, 'annotation'), for i=1:dataNum, DS.annotation{i}=int2str(i); end, end

markerSize=5;
if isfield(DS, 'output')
	DS.output=classOutputConvert(DS.output);	% Convert the output to be intergers from 1 to classNum
	classNum=length(unique(DS.output));
	for i=1:classNum
		index=find(DS.output==i);
		xData=DS.input(1, index);
		yData=DS.input(2, index);
		line(xData, yData, 'marker', '.', 'lineStyle', 'none', 'color', getColor(i));
	end
else
	xData=DS.input(1, :);
	yData=DS.input(2, :);
	line(xData, yData, 'marker', '.', 'lineStyle', 'none', 'color', getColor(1));
end

box on
xlabel(DS.inputName{1});
ylabel(DS.inputName{2});
title(DS.dataName);
axis image

% For visual display of annotation on each data point of the plot
if displayAnnotation
	circleH=line(nan, nan, 'marker', 'o', 'color', 'k', 'erase', 'xor');
	textH=text(0, 0, '', 'hori', 'center', 'vertical', 'top', 'erase', 'xor');
	userData.inData=DS.input;
	userData.pointLabel=DS.annotation;
	userData.circleH=circleH;
	userData.textH=textH;
	set(gcf, 'userData', userData);
	set(gcf, 'WindowButtonMotionFcn', 'windowButtonMotionFcn');
	axis image
end

% ====== Self demo
function selfdemo
dataNum=100;
DS.input=2*rand(2, dataNum)-1;
DS.output=DS.input(1,:)+DS.input(2,:)>0;
DS.dataName='Test Data (Click the data point to show its index)';
for i=1:length(DS.output)
	DS.annotation{i}=sprintf('��%d�����\n(%f, %f)', i, DS.input(1,i), DS.input(2,i));
end
feval(mfilename, DS);