function recog = fldainsel(feature, class, dim, k1, k2);
%LDAINSEL LDA for input selection
%	Usage: recog = fldainsel(feature, class, dim, k1, k2);
%		feature: Feature matrix
%		class: class of each feature vector
%		dim: No. of selected dimension
%		k1: Value of k as in k-nearest neighbor for leave-one-out estimate
%		k2: Value of k for fuzzification class label
%		
%	Type "fldainsel" for self demo.

%	Roger Jang, 20010226

if nargin==0; selfdemo; return; end
if nargin<5, k2=3; end
if nargin<4, k1=1; end
if nargin<3, dim=size(feature,2); end

dataNum = size(feature,1);
dimNum = size(feature,2);
data = [feature, class];

sampleIn = data(:, 1:end-1);
sampleOut = data(:, end);
sampleFuzzyOut = initfknn(data, k2);

fprintf('Leave-one-out analysis:\n');
fprintf('\tFull data:\n');
wrong = looknn(data, k1); 
correct = size(data, 1) - wrong;
fprintf('\t\tLOO error count = %g\n', wrong);
fprintf('\t\tRecognition rate = %g/%g = %5.2f%%\n', correct, dataNum,...
	correct/dataNum*100);

recog = zeros(dimNum, 1);
newSampleIn = flda(feature, sampleFuzzyOut);
for i = 1:dimNum,
	fprintf('\tPartial data after LDA (dimension = %g):\n', i);
	wrong = looknn([newSampleIn(:, 1:i) sampleOut], k1); 
	correct = size(data, 1) - wrong;
	recog(i) = correct/dataNum*100;
	fprintf('\t\tLOO error count = %g\n', wrong);
	fprintf('\t\tRecognition rate = %g/%g = %5.2f%%\n', correct, ...
		dataNum, recog(i));
end

% ====== Self demo
function selfdemo
load wine.dat;
feature = inputNormalize(wine(:,2:end));
class = wine(:,1);
dim = size(feature,2);
recog = feval(mfilename, feature, class, dim);
figure
plot(1:dim, recog, '-o');
xlabel('Dimensions used in LDA');
ylabel('Leave-one-out recognition rates');
