function label2 = classOutputConvert(label)
% classOutputConvert: Convert class output (labels) into integers from 1 to n
%	Usage: label2 = labelConvert(label)

%	Roger Jang, 19970410, 20040928

if nargin<1; selfdemo; return; end

label=double(label);
[sortedLabel, count]=elementCount(label);
label2=label;
for i=1:length(sortedLabel)
	label2(label==sortedLabel(i))=i;
end

% ====== Self demo
function selfdemo
label=[-1 -1 -2 -2 -1 5 9];
label2=feval(mfilename, label);
fprintf('label = \n');
disp(label);
fprintf('After calling "label2=labelConvert(label)"...\n');
fprintf('label2 = \n');
disp(label2);