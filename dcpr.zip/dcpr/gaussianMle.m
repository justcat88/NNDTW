function gaussianParam = gaussianMle(feature, plotOpt)
% mleGaussian: Maximum likelihood estimator for Gaussian distribution
%	gaussianParam = mleGaussian(feature)
%		gaussianParam.mu: MLE of the mean
%		gaussianParam.sigma: MLE of the variance
%	feature: Feature matrix where each column corresponds to a vector
%
%	For example:
%		dataNum=1000;
%		x = randn(dataNum, 1);
%		plotOpt=1;
%		gaussianParam=gaussianMle(x, plotOpt);

%	Roger Jang, 20000428, 20080726

if nargin<1, selfdemo; return; end
if nargin<2, plotOpt=0; end

if size(feature, 2)==1, feature=feature'; end
[dim, dataNum] = size(feature);
if dataNum<=dim
	fprintf('Warning: dataNum<=dim, the resulting parameters are not trustworthy!\n');
end

gaussianParam.mu = mean(feature, 2);
gaussianParam.sigma = (feature*feature'-dataNum*gaussianParam.mu*gaussianParam.mu')/(dataNum-1);

if plotOpt
	if dim==1
		binNum = 20;
		[N, X] = hist(feature, binNum);
		maxX=max(feature);
		minX=min(feature);
		rangeX=maxX-minX;
		k = dataNum*rangeX/binNum;
		bar(X, N/k, 1);
		xi = linspace(minX-rangeX/2, maxX+rangeX/2);
		yi = gaussian(xi, gaussianParam);
		hold on
		h = plot(xi, yi);
		hold off
		set(h, 'linewidth', 2, 'color', 'r');
		title('Gaussian PDF');
	end
end

% ====== Self demo
function selfdemo
dataNum = 1000;
% ====== Gaussian PDF
x = randn(dataNum, 1);
plotOpt=1;
subplot(2,1,1);
feval(mfilename, x, plotOpt);
% ====== Uniform PDF
x = rand(dataNum, 1);
subplot(2,1,2);
feval(mfilename, x, plotOpt);
title('Uniform PDF');
