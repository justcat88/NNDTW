function [input, class] = dec2pos(data);
%DEC2POS Output data transformation
%	[INPUT, CLASS] = DEC2POS(DATA)
%	DATA is input plus output; the output is the last column of DATA
%		(The output takes value from 1 to n, where n is the total number
%		of classes.)
%	INPUT is DATA(:, 1:end-1);
%	CLASS is position representation of the last column of DATA
%		(The size of CLASS is data_nxn.)

data_n = size(data, 1);
class_n = max(data(:,end));

input = data(:, 1:end-1);
class = zeros(data_n, class_n);
for i = 1:class_n,
	index = find(data(:,end)==i);
	class(index, i) = 1;
end
