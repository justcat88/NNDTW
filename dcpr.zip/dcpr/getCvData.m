function cvData=getCvData(DS, m)
% getcvData: Get m-fold cross validation data
%	Usage: cvData=getCvData(DS, m)
%
%	For example:
%		DS=prData('iris');
%		cvData=getCvData(DS, 5);		

%	Roger Jang, 20070410

if nargin<1, selfdemo; return; end

[dim, dataNum]=size(DS.input);
subSize=round(dataNum/m);

[classLabel, classSize]=elementCount(DS.output);
classNum=length(classLabel);
for i=1:classNum
	classIndex{i}=find(i==DS.output);	% Indices of data in class i
end

for i=1:m	
	cvData(i).DS.input=[];
	cvData(i).DS.output=[];
	cvData(i).TS.input=[];
	cvData(i).TS.output=[];
	index=[];
	for j=1:classNum
		subSize=round(classSize(j)/m);
		if i~=m
			indexRange=((i-1)*subSize+1):(i*subSize);
		else
			indexRange=((m-1)*subSize+1):length(classIndex{j});
		end
		index=[index, classIndex{j}(indexRange)];
	end	
	cvData(i).DS.input=DS.input;
	cvData(i).DS.output=DS.output;
	cvData(i).DS.input(:, index)=[];
	cvData(i).DS.output(:, index)=[];
	tempIndex=1:dataNum;
	tempIndex(index)=[];
	cvData(i).DS.index=tempIndex;
	cvData(i).TS.input=DS.input(:, index);
	cvData(i).TS.output=DS.output(:, index);
	cvData(i).TS.index=index;
end

% ====== Self demo
function selfdemo
DS=prData('iris');
cvData=getCvData(DS, 5);
cvData(1).DS
cvData(1).TS