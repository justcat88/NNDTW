function [center, U] = vqLBG(data, codeBookSize, dispOpt, kmeansFcn)
% vqLBG: Vector quantization using LBG method of center splitting
%	Usage: [center, U]=vq(data, codeBookSize, dispOpt)
%		data : dataNum x dataDim.
%		codeBookSize : codebook size or number of cluster centers (should be the power of 2)
%		dispOpt: Option for displaying information during computation (Optional, default=0)
%		kmeansFcn: K-means function employed in the iteration (Optional, default="vqKmeansMex")

%	Roger Jang, 20030330

if nargin<1, selfdemo; return; end
if nargin<3, dispOpt=0; end
if nargin<4, kmeansFcn='vqKmeans'; end

% ====== Error checking
[dataDim, dataNum] = size(data);

% Initial Centers: mean of all data
center= mean(data,2);

if dispOpt
	plot(data(1,:), data(2,:), 'b.');
	centerH=line(center(1,:), center(2,:), 'color', 'r', 'marker', 'o', 'linestyle', 'none', 'linewidth', 2);
	axis image
end;

% Do while-loop to increase center number till it is equal to or greater than codebook size.
maxLoopCount = 100;
centerNum = size(center,2);
while (centerNum<codeBookSize)
	if dispOpt
	%	fprintf('Hit return to start center splitting...\n'); pause;
		pause(1.0);
	end
	center=[center-eps, center+eps];	% Center splitting
	centerNum=size(center,2);
	[center, U, distortion] = feval(kmeansFcn, data, center, dispOpt);	% VQ using K-means function
	fprintf('No. of centers = %g, loop count = %g, distortion = %g\n', centerNum, length(distortion), distortion(end));   
end
if dispOpt, vqDataPlot(data, center); end

% ====== Self demo
function selfdemo
data = dcdata(2)';
codeBookSize=2^5;
dispOpt=1;
kmeansFcn='vqKmeans';
codebook = feval(mfilename, data.input, codeBookSize, dispOpt, kmeansFcn);