function recogRate=pcaKnnrLoo(DS, plotOpt)
% ldaKnnrLoo: PCA analysis using KNNR and LOO

%	Roger Jang, 20060507

if nargin<1, selfdemo; return; end
if nargin<2, plotOpt=0; end

[featureNum, dataNum] = size(DS.input);
DS2 = pca(DS);
recogRate=[];
for i = 1:featureNum
	DS3=DS2; DS3.input=DS2.input(1:i, :);
	[recogRate(i), hitIndex] = knnrLoo(DS3);
	hitCount=length(hitIndex);
%	fprintf('\t\tLOO recog. rate = %d/%d = %g%%\n', hitCount, dataNum, 100*recogRate(i));
end

if plotOpt
	plot(1:featureNum, 100*recogRate, 'o-'); grid on
	xlabel('No. of projected features based on PCA');
	ylabel('LOO recognition rates using KNNR (%)');
end

% ====== Self demo
function selfdemo
DS=prData('wine');
feval(mfilename, DS, 1);