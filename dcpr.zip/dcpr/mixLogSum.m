function output=mixLogSum(input)
% mixLogSum: Compute the mixture log sum
%	Usage: output=mixLogSum(input)
%		input=[x, y, z..] is the input vector
%		output=log(e^x + e^y + e^z...)
%	
%	This function is more robust, For instance, compare the difference:
%		mixLogSum([-2000, -1999])
%		log(sum(exp([-2000, -1999])))
%
%	This function is primarily used for computing the log probability of a GMM.
%	For efficiency, you can use the equivalent mixLogSumMex.dll instead.

%	Roger Jang, 20070324

%input=flipud(sort(input(:)));
output=input(1);
for i=2:length(input)
	if output<input(i)
		temp=output; output=input(i); input(i)=temp;
	end
	output=output+log(1+exp(input(i)-output));
end