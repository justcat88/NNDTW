function [classParam, recogRate, hitIndex]=qcTrain(DS, prior, plotOpt)
% qcTrain: Training the quadratic classifier
%	Usage: [classParam, recogRate, hitIndex]=qcTrain(DS, prior, plotOpt)
%		DS: data set for classification
%		prior: a vector of class prior probability
%			(Equal prior probability will assume if an empty matrix is given.)
%		plotOpt: 1 for plotting
%		classParam: classParam(i) is the parameters for class i, etc.
%		recogRate: recognition rate
%		hitIndex: index of the correctly classified data points
%
%	For example:
%		DS=prData('iris');
%		DS.input=DS.input(3:4, :);
%		plotOpt=1;
%		classParam=qcTrain(DS, [], plotOpt);

% Roger Jang, 20041123, 20080924

if nargin<1, selfdemo; return; end

[dim, dataNum]=size(DS.input);
uniqOutput=unique(DS.output);
classNum=length(uniqOutput);

if nargin<2, prior=ones(classNum, 1); end
if nargin<3, plotOpt=0; end

if isempty(prior), prior=ones(classNum, 1); end

% Identify parameters for each class
classParam=struct([]);
for i=1:length(uniqOutput)
	index=find(DS.output==uniqOutput(i));
	dataCount=length(index);
	temp=gaussianMle(DS.input(:, index)); classParam(i).mu=temp.mu; classParam(i).sigma=temp.sigma;		% How can we combine this into a single statement?
	classParam(i).invSigma=inv(classParam(i).sigma);
	classParam(i).gconst=-0.5*(dim*log(2*pi)+log(det(classParam(i).sigma)));
	classParam(i).weight=prior(i);
	classParam(i).name=uniqOutput(i);
end
[computedClass, recogRate, hitIndex]=qcEval(DS, classParam, plotOpt);

if plotOpt & dim==2
	dcprDataPlot(DS);
	axis image; box on
	missIndex=1:dataNum;
	missIndex(hitIndex)=[];
	% display these points
	for i=1:length(missIndex),
		line(DS.input(1,missIndex(i)), DS.input(2,missIndex(i)), 'marker', 'x', 'color', 'k');
	end
	titleString = sprintf('%d error points denoted by "x".', length(missIndex));
	title(titleString);
end

% ====== Self demo
function selfdemo
DS=prData('iris');
DS.input=DS.input(3:4, :);
plotOpt=1;
classParam=feval(mfilename, DS, [], plotOpt);