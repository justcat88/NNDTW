function [bestSelectedInput, bestRecogRate, allSelectedInput, allRecogRate, elapsedTime] = inputSelectSequential(DS, inputNum, classifier, param, plotOpt)
% inputSelectSequential: Input selection via sequential forward selection using leave-one-out
%	Usage: [bestSelectedInput, allSelectedInput, allRecogRate, elapsedTime] = inputSelectSequential(DS, inputNum, classifier, param, plotOpt)
%
%	Input:
%		DS: design set
%		inputNum: up to inputNum inputs are selected
%		classifier: classifier for input selection
%		param: parameters for classifier
%		plotOpt: 0 for not plotting (default: 1)
%	Output:
%		bestSelectedInput: overall selected input index
%		bestRecogRate: recognition rate based on the final selected input
%		allSelectedInput: all selected input during the process 
%		allRecogRate: all recognition rate 
%		elapseTime: elapsed time

%	Roger Jang, 19971227, 20041102

if nargin<1, selfdemo; return; end
[dim, dataNum]=size(DS.input);
if nargin<2, inputNum=dim; end
if nargin<3, classifier='knnrLoo'; end
if nargin<4, param.k=1; end
if nargin<5, plotOpt=1; end

DS.output=classOutputConvert(DS.output);	% Convert the output to be intergers from 1 to classNum
if ~isfield(DS, 'inputName')
	feaNum=size(DS.input, 1);
	DS.inputName=cellstr(int2str((1:feaNum)'));
end
inputName=DS.inputName;
modelNum=inputNum*(2*dim-inputNum+1)/2;		% No. of KNN models

% ====== Construct KNN with different input variables
fprintf('\nConstruct %d KNN models, each with up to %d inputs selected from %d candidates...\n', modelNum, inputNum, dim);
selectedInput=[];
modelIndex=1;
t0=clock;
for i=1:inputNum
	fprintf('\nSelecting input %d:\n', i);
	recogRate = -realmax*ones(1, dim);
	for j=1:dim,
		if isempty(selectedInput) | isempty(find(selectedInput==j))
			currentSelectedInput = [selectedInput, j];
			DS2=DS;
			DS2.input=DS.input(currentSelectedInput, :);
			recogRate(j) = feval(classifier, DS2, param);
			allRecogRate(modelIndex) = recogRate(j);
			fprintf('Model %d/%d:', modelIndex, modelNum);
			fprintf('%s --> Recognition rate = %.1f%%\n', inputNameList(currentSelectedInput, inputName), recogRate(j)*100);
			allSelectedInput{modelIndex} = currentSelectedInput;
			modelIndex = modelIndex+1;
		end
	end
	[a, b] = max(recogRate);
	selectedInput = [selectedInput, b];
	fprintf('Currently selected inputs: %s\n', inputNameList(selectedInput, inputName));
end

[bestRecogRate, b] = max(allRecogRate);
bestSelectedInput = allSelectedInput{b};
fprintf('\nOverall maximal recognition rate = %.1f%%.\n', bestRecogRate*100);
fprintf('Overall selected inputs: %s\n', inputNameList(bestSelectedInput, inputName));
elapsedTime=etime(clock, t0);

if plotOpt
	inputSelectPlot(allRecogRate*100, allSelectedInput, inputName, mfilename);
end

% ====== Self demo
function selfdemo
DS=prData('iris');
feval(mfilename, DS);
