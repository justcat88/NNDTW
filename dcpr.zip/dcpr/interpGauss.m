function finalOutput=interpGauss(x, sampleData)
% INTERPGAUSS	�H normalized gaussian basis function �Ӷi�氪�����t�B��

if nargin==0, selfdemo; return; end

dataNum=size(sampleData,1);
inputNum=size(sampleData,2)-1;
input=sampleData(:, 1:end-1);
output=sampleData(:, end);
distance=zeros(dataNum,1);

% ====== Normalization of sample data
colMin=min(input);
colMax=max(input);
for i=1:inputNum,
	input(:,i)=(input(:,i)-colMin(i))/(colMax(i)-colMin(i));
end
% ====== Normalization of test data
x=(x-colMin)./(colMax-colMin);

sigma=0.3;
% ====== Compute weight matrix of Gaussians
weight=zeros(dataNum, dataNum);
for i=1:dataNum,
	gPrm.mu=input(i,:); gPrm.sigma=sigma;
	weight(:,i)=gaussian(input, gPrm); 
end
% ====== Compute normalized weight matrix
normalizedWeight=diag(1./sum(weight,2))*weight;

% ====== Compute desired output of each Gaussian
gaussianOutput=normalizedWeight\output;

% ====== Compute the final output
weight=zeros(1, dataNum);
for i=1:dataNum
	gPrm.mu=input(i,:); gPrm.sigma=sigma;
	weight(i)=gaussian(x, gPrm); 
end
normalizedWeight=weight/sum(weight);
finalOutput=normalizedWeight*gaussianOutput;

% ====== subfunction for selfdemo
function selfdemo
sampleData=[1 3; 2 5; 3 6; 5 7; 7 8; 6 7.5];
%sampleData=randn(10,2);
x=linspace(min(sampleData(:,1)), max(sampleData(:,1)));
y=0*x;
for i=1:length(y);
	y(i)=feval(mfilename, x(i), sampleData);
end
plot(x, y);
hold on
plot(sampleData(:,1), sampleData(:,2), 'o');
hold off