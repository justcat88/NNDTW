function [fn, fp]=rocPlot(data1, data2, scaleMode)
% rocPlot: Plot for receiver operating curve
%	Usage: rocPlot(data1, data2)
%		data1: vector for data of negative set
%		data2: vector for data of positive set
%		scaleMode: 'log' or 'linear'
%
%	For example:
%		data1=randn(1,300)-1;
%		data2=randn(1,300)+1;
%		subplot(1,2,1);
%		rocPlot(data1, data2);
%		subplot(1,2,2);
%		rocPlot(data1, data2, 'log');

%	Roger Jang, 20061025

if nargin<3, scaleMode='linear'; end
if nargin<1, selfdemo; return; end

[th, fp, fn, gParam1, gParam2, a, b, ths, fps, fns]=roc(data1, data2);

plot(fns*100, fps*100, '.-');
set(gca, 'xscale', scaleMode, 'yscale', scaleMode);
xlabel('False-negative error rate (%)');
ylabel('False-positive error rate (%)'); 

[junk, id(1)]=min(abs(fns-fps));
[junk, id(2)]=min(abs(5*fns-fps));
[junk, id(3)]=min(abs(fns-5*fps));
for i=1:length(id);
	index=id(i);	
	th=ths(index);
	line(fns(index)*100, fps(index)*100, 'color', 'r', 'marker', 'o');
	text(fns(index)*100, fps(index)*100, sprintf('  \\theta=%.4f (fn=%.4f%%, fp=%.4f%%)', th, 100*fns(index), 100*fps(index)));
end
axis square, grid on

% ====== Self demo
function selfdemo
data1=randn(1,100)*5;
data2=randn(1,300)*2+3;
subplot(1,2,1);
feval(mfilename, data1, data2);
subplot(1,2,2);
feval(mfilename, data1, data2, 'log');