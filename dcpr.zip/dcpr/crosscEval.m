function [output, recogRate]=crosscEval(DS, coef)
%crosscEval: Evaluation of cross classifier
%	Usage: [output, recogRate]=crosscEval(DS, coef)

%	Roger Jang, 20041106

xCut=coef(1);
yCut=coef(2);
xSign=coef(3);
ySign=coef(4);
andOpt=coef(5);	%1 for AND, 0 for OR

dataNum=size(DS.input,2);
if xSign>0
	index1=DS.input(1,:)>xCut;
else
	index1=DS.input(1,:)<xCut;
end

if ySign>0
	index2=DS.input(2,:)>yCut;
else
	index2=DS.input(2,:)<yCut;
end

if andOpt>0
	index=index1 & index2;
else
	index=index1 | index2;
end

output=-ones(1, dataNum);			% Classification output
output(index)=1;

if isfield(DS, 'output')
	recogRate=sum(output==DS.output)/dataNum;	% Classification recognition rate
	errorIndex1=find(DS.output<0 & output>0);	% - ===> +
	errorIndex2=find(DS.output>0 & output<0);	% + ===> -
end