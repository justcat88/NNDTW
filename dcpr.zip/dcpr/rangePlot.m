function rangeVec = rangePlot(DS)
%rangePlot: range plot of a data set
%	Usage: rangeVec = rangePlot(DS)

%	Roger Jang, 20070416

if nargin<1, selfdemo; return; end

rangeVec=range(DS.input');
[featureNum, dataNum] = size(DS.input);		% no. of features
bar(1:featureNum, rangeVec);
xlabel('Feature indices');
ylabel('Range');
if isfield(DS, 'dataName')
	title(sprintf('Range Plot for "%s"', DS.dataName))
end
if isfield(DS, 'inputName')
	for i=1:featureNum
		text(i, rangeVec(i), DS.inputName{i}, 'vertical', 'bottom', 'horizon', 'center', 'color', 'r');
	end
end

% ====== Self demo
function selfdemo
DS=prData('abalone');
rangeVec=rangePlot(DS);