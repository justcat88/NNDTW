function [DS2, eigVec, eigValue] = pca(DS, eigVecNum)
%pca: Principal component analysis
%	Usage: [DS2, eigVec, eigValue] = pca(DS, eigVecNum)
%		DS: DS.input is the data matrix, where each column is a data vector
%			Please try "DS=dcData(1)" to get an example of DS.
%		eigVecNum: No. of selected eigenvectors
%		DS2: output data set, where DS2.input is the data after projection
%		eigVec: Each column of this matrix is a eigenvector of DS.input*DS.input' sorted by its decending order of eigen values
%		eigValue: Eigenvalues of (DS.input*DS.input') corresponding to eigVec
%
%	Note that DS.input must be zero-mean'ed before calling this function. 
%
%	Type "pca" for a self-demo.

%	Roger Jang, 970406, 990612, 991215, 20060506

if nargin<1, selfdemo; return; end
if ~isstruct(DS)
	fprintf('Please try "DS=prData(1)" to get an example of DS.\n');
	error('The input DS should be a structure variable!');
end
if nargin<2, eigVecNum = min(size(DS.input)); end

m = size(DS.input,1);	% Dimension of data point
n = size(DS.input,2);	% No. of data point
A = DS.input;

if n>=m
	[eigVec, eigValue] = eig(A*A');
	eigValue = diag(eigValue);
	% ====== Sort based on descending order
	[junk, index] = sort(-eigValue);
	eigValue = eigValue(index);
	eigVec = eigVec(:, index);
	if eigVecNum<m
		eigValue = eigValue(1:eigVecNum);
		eigVec = eigVec(:, 1:eigVecNum);
	end
else	% This is an efficient method which computes the eigvectors of A*A' when size(A,1)>size(A,2)
	% A*A'*x=lambda*x ===> A'*A*A'*x=lambda*A'*x ===> eigVec of A'*A is A'*x, multiply these eigVec by A, we have A*A'*x=lambda*x ===> Got it!
	[eigVec, eigValue] = eig(A'*A);
	eigValue = diag(eigValue);
	% ====== Sort based on descending order
	[junk, index] = sort(-eigValue);
	eigValue = eigValue(index);
	eigVec = eigVec(:, index);		% Eigenvectors of A'*A
	eigVec = A*eigVec;			% Eigenvectors of A*A'
	eigVec = eigVec*diag(1./(sum(eigVec.^2).^0.5)); % Normalization
	if eigVecNum<n
		eigValue = eigValue(1:eigVecNum);
		eigVec = eigVec(:, 1:eigVecNum);
	end
end

DS2=DS;
DS2.input=eigVec'*A;


% ====== Self demo
function selfdemo
	% ====== Demo for 2D data
	dataNum = 1000;
	data = randn(1,dataNum)+j*randn(1,dataNum)/3;
	data = data*exp(j*pi/6);	% ����30��
	data = data-mean(data);		% �����ȵ���s
	plot(real(data), imag(data), '.'); axis image;
	DS.input=[real(data); imag(data)];
	[DS2, v, eigValue] = feval(mfilename, DS);
	v1 = v(:, 1);
	v2 = v(:, 2);
	arrow = [-1 0 nan -0.1 0 -0.1]+1+j*[0 0 nan 0.1 0 -0.1];
	arrow1 = 2*arrow*(v1(1)+j*v1(2))*eigValue(1)/dataNum;
	arrow2 = 2*arrow*(v2(1)+j*v2(2))*eigValue(2)/dataNum;
	line(real(arrow1), imag(arrow1), 'color', 'r', 'linewidth', 4);
	line(real(arrow2), imag(arrow2), 'color', 'k', 'linewidth', 4);
	title('Axes for PCA');

	% ====== Demo for Iris data
	DS=prData('iris');
	dataNum = size(DS.input, 2);
	DS.input = DS.input-mean(DS.input, 2)*ones(1, dataNum);	% Make data zero-mean
	DS2=feval(mfilename, DS);
	figure; dcprDataPlot(DS2); title('IRIS projected on the first 2D of LDA');
	DS2.input=DS2.input(3:4, :);
	figure; dcprDataPlot(DS2); title('IRIS projected on the last 2D of LDA');