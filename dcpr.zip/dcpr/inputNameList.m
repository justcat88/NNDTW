function str=inputNameList(inputIndex, inputName)
str=inputName{inputIndex(1)};
for i=2:length(inputIndex)
	str = [str, ', ', inputName{inputIndex(i)}];
end