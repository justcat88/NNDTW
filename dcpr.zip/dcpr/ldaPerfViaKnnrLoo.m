function recogRate=ldaPerfViaKnnrLoo(DS, maxDim, plotOpt)
% ldaPerfViaKnnrLoo: LDA recognition rate via KNNR classifier and LOO performance index
%	Usage: recogRate=ldaPerfViaKnnrLoo(DS)
%		recogRate=ldaPerfViaKnnrLoo(DS, [], plotOpt)
%		recogRate=ldaPerfViaKnnrLoo(DS, maxDim, plotOpt)
%
%	For example:
%		DS=prData('wine');
%		recogRate1=ldaPerfViaKnnrLoo(DS, [], 1);

%	Roger Jang, 20060507

if nargin<1, selfdemo; return; end
[featureNum, dataNum] = size(DS.input);
if nargin<2, maxDim=featureNum; end
if nargin<3, plotOpt=0; end

if isempty(maxDim), maxDim=featureNum; end
if isnan(maxDim), maxDim=featureNum; end
maxDim=min(maxDim, featureNum);

DS2 = lda(DS);
recogRate=[];
for i = 1:maxDim
	DS3=DS2; DS3.input=DS2.input(1:i, :);
	[recogRate(i), hitIndex] = knnrLoo(DS3);
	hitCount=length(hitIndex);
	if plotOpt
		fprintf('\t\tLOO recog. rate of KNNR using %d dim = %d/%d = %g%%\n', i, hitCount, dataNum, 100*recogRate(i));
	end
end

if plotOpt
	plot(1:maxDim, 100*recogRate, 'o-'); grid on
	xlabel('No. of projected features based on LDA');
	ylabel('LOO recognition rates using KNNR (%)');
end

% ====== Self demo
function selfdemo
DS=prData('wine');
%DS.output=classOutputConvert(DS.output);	% Since the class labels are not consecutive...
recogRate1=feval(mfilename, DS);
DS.input=inputNormalize(DS.input);
recogRate2=feval(mfilename, DS);
plot(1:length(recogRate1), 100*recogRate1, '.-', 1:length(recogRate2), 100*recogRate2, '.-'); grid on
xlabel('No. of projected features based on LDA');
ylabel('LOO recognition rates using KNNR (%)');
legend('Without input normalization', 'With input normalization', 'location', 'southwest');
