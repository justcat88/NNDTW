function inputSelectPlot(allRecogRate, allSelectedInput, inputName, callingFunction);
% inputSelectPlot: Plot for input selection
%	Usage: inputSelectPlot(allRecogRate, allSelectedInput, inputName, callingFunction);

%	Roger Jang, 20041102

modelNum=length(allRecogRate);
% ====== Display the results
x = (1:modelNum)';
subplot(211);
plot(x, allRecogRate, '-', x, allRecogRate, 'ko');
tmp = x(:, ones(1, 3))';
X = tmp(:);
tmp = [zeros(modelNum, 1), allRecogRate(:), nan*ones(modelNum, 1)]';
Y = tmp(:);
hold on; plot(X, Y, 'g'); hold off;
[a, b] = max(allRecogRate);
hold on; plot(b, a, 'r*'); hold off;
axis([1 modelNum -inf inf]);
set(gca, 'xticklabel', []);
ylabel('LOO Recognition Rates (%)');
grid on
%h = findobj(gcf, 'type', 'line'); set(h, 'linewidth', 2)

% ====== Add text of input variables
for i=1:modelNum
	text(x(i), 0, inputNameList(allSelectedInput{i}, inputName));
end
h = findobj(gcf, 'type', 'text'); set(h, 'rot', 90, 'fontsize', 11, 'hori', 'right');
ylabel('Recognition rates (%)');
title(['Recognition rates using ', callingFunction, ': ', int2str(modelNum), ' Models']);