function hclustdm(pattern_mat, distance, level)
% LINKCLU Display the formation of hierarchical clustering step by step
%
%	Usage: hclustdm(pattern_mat, distance, level)
%	pattern_mat: pattern matrix
%	distance: distance matrix of the pattern matrix
%	level: hierarchical clustering result of the patern matrix
%
%	Type "hclustdm" to see a demo of a step-by-step hierarchical clustering
%	(single-linkage) of 50 random patterns of dimensionality 2.
%
%	See also AGGCLUST, DENDRO.

%	Roger Jang, 981027

% Demo when no input arguments
if nargin == 0, selfdemo; return, end

plot(pattern_mat(:, 1), pattern_mat(:, 2), 'go');
axis equal;
axis square;
data_n = size(pattern_mat, 1);
for i = 2:data_n,
	if i>=3, set(h, 'color', 'b'); end
	[m, n] = find(distance==level(i).height);
	h = line(pattern_mat(m,1), pattern_mat(m,2), 'color', 'r', 'erase', 'none');
	drawnow;
%	fprintf('Press any key to form %g clusters ...\n', data_n-i+1); pause;
	pause(0.1);
end

% ====== Self demo ======
function selfdemo
data_n = 50;
dimension = 2;
points = rand(data_n, dimension);
for i = 1:data_n,
	for j = 1:data_n,
		distance(i, j) = norm(points(i,:)-points(j,:));
	end
end

% Diagonal elements should always be inf.
for i = 1:data_n, distance(i, i) = inf; end

level = aggclust(distance);

% Plot heights w.r.t. levels
%figure;
%plot([level.height], 'r:o');
%xlabel('Level');
%ylabel('Height');
%title('Height vs. level');

% Plot the dendrogram
figure;
dendro(level);

% View the formation of clusters
figure;
title('Press any key to link clusters.');
feval(mfilename, points, distance, level);
title('The whole data set has been linked to a single cluster!');
