function center = vqInitCenter(data, clusterNum, method)
% vqInitCenter: Find initial centers for VQ or k-means
%	Usage: center = vqInitCenter(data, clusterNum, method)

%	Roger Jang, 20041204

if nargin<3; method=1; end
switch method
	case 1
		% ====== Method 1: Randomly pick clusterNum data points as cluster centers
		dataNum = size(data, 2);
		temp = randperm(dataNum);
		center = data(:, temp(1:clusterNum));
	case 2
		% ====== Method 2: Choose clusterNum data points closest to mean vector
		meanVec = mean(data, 2);
		distMat = pairwiseSqrDistance(meanVec, data);
		[minDist, colIndex] = sort(distMat);
		center = data(:, colIndex(1:clusterNum));
	case 3
		% ====== Method 3: Choose clusterNum data points furthest to the mean vector
		meanVec = mean(data, 2);
		distMat = pairwiseSqrDistance(meanVec, data);
		[minDist, colIndex] = sort(-distMat);
		center = data(:, colIndex(1:clusterNum));
	case 4
		% ====== Method 4: Choose first few data as the centers
		center = data(:, 1:clusterNum);
	otherwise
		error('Unknown method!');
end
