function [misclassify, elapsed_time] = knnrLooWrtK(DS, kMax, plotOpt)
% knnrWrtK: Try various values of K in leave-one-out K-NNR.
%	[misclassify, elapsed_time] = knnrLooWrtK(DS, kMax, plotOpt)

%	Roger Jang, 19971227, 20080924

if nargin<1, selfdemo; return; end
if nargin<2, kMax=15; end
if nargin<3, plotOpt=0; end

designNum=size(DS.input, 2);
for k=1:kMax
	knnrParam.k=k;
	recog(k)=knnrLoo(DS, knnrParam);
	fprintf('\t%d-NNR ===> %.2f%%.\n', k, recog(k)*100);
end

if plotOpt
	plot(1:kMax, recog*100, 'b-o'); grid on;
	title('Recognition rates using K-NNR');
	xlabel('K'); ylabel('Recognition rates (%)');
end


function selfdemo
DS=prData('iris');
designNum=size(DS.input, 2);
fprintf('Use of KNNRLOO for Iris data:\n');
fprintf('\tSize of DS = %d\n', designNum);
kMax=20;
plotOpt=1;
knnrLooWrtK(DS, kMax, plotOpt);