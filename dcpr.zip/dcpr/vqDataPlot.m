function vqDataPlot(data, center)
% vqDataPlot: Plot the result of vector quantization (used in kmeans.m and vqLBG.m)

% Find U (Copied from vqKmeans.m)
dim = size(data, 1);
dataNum = size(data, 2);
centerNum = size(center, 2);
% ====== Compute distance matrix
distMat=pairwiseSqrDistance(center, data);
% ====== Find the U (partition matrix)
[minDist, colIndex] = min(distMat);
U = zeros(size(distMat));
U(colIndex+centerNum*(0:dataNum-1)) = 1;

% Plot data
DS.input=data;
[junk, DS.output]=max(U);
dcprDataPlot(DS);

% Display the centers
clusterNum = size(center,2);
for i=1:clusterNum,
	line(center(1,i), center(2,i), 'color', 'k', 'marker', 'o', 'linestyle', 'none', 'linewidth', 2, 'markerSize', 10);
end