function [data2, mu1, sigma1] = inputNormalize(data, plotOpt, mu, sigma)
% inputNormalize: Input (feature) normalization to have zero mean and unity variance for each feature
%	Usage: [data2, MU1, SIGMA1] = inputNormalize(data, plotOpt)
%	       data2 = inputNormalize(data, MU, SIGMA)
%		data: Input feature matrix, where each column is a data point
%			and each column being the values for a specific feature.
%		data2: Output feature matrix with zero mean and unity variance for each feature.
%
%	If the function has three inputs, then the normalization is performed
%	using the supplied MU and SIGMA. If the function has only one inputs,
%	MU1 and SIGMA1 are calculated (and returned) based on data.

%	Roger Jang, 20040925

if nargin<1, selfdemo; return; end
if nargin<2, plotOpt=0; end

dim = size(data, 1);
dataNum = size(data, 2);

if nargin<=2
	mu1 = mean(data, 2);
	sigma1 = sqrt(diag(cov(data')));
	data2 = data-mu1*ones(1,dataNum,1);
	data2 = diag(1./sigma1)*data2;
else
	sigma=mu;
	mu=plotOpt;
	data2 = data-mu(:)*ones(1,dataNum,1);
	data2 = diag(1./sigma)*data2;
end

if plotOpt
	subplot(1,2,1);
	plot(data(1,:), data(2,:), '.'); axis image
	title('Original data');
	subplot(1,2,2);
	plot(data2(1,:), data2(2,:), '.'); axis image
	title('Normalized data');
end

% ====== Self demo
function selfdemo
dataNum=100;
x=8*randn(1, dataNum);
y=randn(1, dataNum)+100;
data=[x; y];
plotOpt=1;
feval(mfilename, data, plotOpt);