x=linspace(-2, 10);
y1=exp(-x);
y2=cos(x);
subplot(2,1,1); plot(x, y1, x, y2);
subplot(2,1,2); plot(x, y1-y2);

figure
plot(x, y1-y2);
axis([4 8 -2 2])