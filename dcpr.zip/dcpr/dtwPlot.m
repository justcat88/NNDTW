function dtwplot(vec1, vec2, dtwPath, dtwPath2) 
%DTWPLOT Plot the result of DTW of two pitch/MFCC vectors
%	Usage:
%	dtwplot(vec1, vec2, dtwPath)
%
%	For example:
%		vec1=[71 73 75 80 80 80 78 76 75 73 71 71 71 73 75 76 76 68 76 76 75 73 71 70 70 69 68 68 72 74 78 79 80 80 78];
%		vec2=[69 69 73 75 79 80 79 78 76 73 72 71 70 70 69 69 69 71 73 75 76 76 76 76 76 75 73 71 70 70 71 73 75 80 80 80 78];
%		[minDist1, dtwPath1, dtwTable1] = dtw1(vec1, vec2);
%		[minDist2, dtwPath2, dtwTable2] = dtw2(vec1, vec2);
%		dtwplot(vec1, vec2, dtwPath1, dtwPath2);

%	Roger Jang, 20020428, 20070522

if nargin<1; selfdemo; return; end

if size(vec1,1)>1 & size(vec1,2)>1 & size(vec2,1)>1 & size(vec2,2)>1	% Inputs are MFCC matrices for ASR
	frame1num = size(vec1, 2);
	frame2num = size(vec2, 2);

	% Vertical yellow grid line
	for i = 1:frame1num,
		line([i, i], [1, frame2num], 'color', 'y');
	end
	% Horizontal yellow grid line
	for j = 1:frame2num,
		line([1, frame1num], [j, j], 'color', 'y');
	end

	% ====== Solution obtained by DTW
	for i = 1:size(dtwPath,2)-1,
		line([dtwPath(1,i), dtwPath(1,i+1)], [dtwPath(2,i), dtwPath(2,i+1)], 'color', 'r', 'marker', '.');
	end
	if nargin==4,	% Another DTW path via different DTW method
		for i = 1:size(dtwPath2,2)-1,
			line([dtwPath2(1,i), dtwPath2(1,i+1)], [dtwPath2(2,i), dtwPath2(2,i+1)], 'color', 'k', 'marker', '.');
		end
	end
	xlabel(inputname(1));
	ylabel(inputname(2));
	if ~isempty(dtwPath),
		temp = vec1(:,dtwPath(1,:))-vec2(:,dtwPath(2,:));
		dtwDist = sum(sqrt(sum(temp.^2)));
	else
		dtwDist = inf;
	end
	title(['DTW total distance = ', num2str(dtwDist)]);
	box on
	axis tight
	axis image
	return
end

vec1=vec1(:);
vec2=vec2(:);
pos = get(gcf, 'pos');
width = pos(3);
height = pos(4);
% Assume width > height
% Assume the aspect ratio of the signal axis is b:1
b = 4;
k = height/(b+2.5);

vec1Axis = subplot(2,2,4);
plot(1:length(vec1), vec1, 1:length(vec1), vec1, 'r.');
axis tight
ylabel('vec1');
set(vec1Axis, 'unit', 'pixels');
set(vec1Axis, 'position', [width-(b+0.5)*k, height-(b+2)*k, b*k, k]); 

vec2Axis = subplot(2,2,1);
plot(min(vec2)+max(vec2)-vec2, 1:length(vec2), min(vec2)+max(vec2)-vec2, 1:length(vec2), 'r.');
axis tight;
xlabel('vec2');
set(vec2Axis, 'unit', 'pixels');
set(vec2Axis, 'position', [width-(b+2)*k, height-(b+0.5)*k, k, b*k]); 
% The following should be done after axis is resized
xticklabel = get(vec2Axis, 'xticklabel');
set(vec2Axis, 'xticklabel', flipud(xticklabel));

pathAxis = subplot(2,2,2);
box on;
set(pathAxis, 'unit', 'pixels');
position = [width-(b+0.5)*k, height-(b+0.5)*k, b*k, b*k]; 
set(pathAxis, 'position', position); 
% Plot the yellow grid line
for i = 1:length(vec1),
	line([i, i], [1, length(vec2)], 'color', 'y');
end
for i = 1:length(vec2),
	line([1, length(vec1)], [i, i], 'color', 'y');
end
% ====== Solution obtained by DTW
for i = 1:size(dtwPath,2)-1,
	line(dtwPath(1, i:i+1), dtwPath(2, i:i+1), 'color', 'r', 'marker', '.');
end
if ~isempty(dtwPath),
	dtwDist = sum(abs(vec1(dtwPath(1,:))-vec2(dtwPath(2,:))));
else
	dtwDist = inf;
end
title(sprintf('DTW total distance = %g', dtwDist));

if nargin==4,	% Another DTW path via different DTW method
	for i = 1:size(dtwPath2,2)-1,
		line(dtwPath2(1, i:i+1), dtwPath2(2, i:i+1), 'color', 'k', 'marker', '.');
	end
	if ~isempty(dtwPath2),
		dtwDist2 = sum(abs(vec1(dtwPath2(1,:))-vec2(dtwPath2(2,:))));
	else
		dtwDist2 = inf;
	end
	title(sprintf('DTW total distances = %g, %g', dtwDist, dtwDist2));
end

axis equal
axis tight

if length(vec2)>length(vec1),
	% Adjust the axis of vec1
	dtwPlotWidth = position(3)*length(vec1)/length(vec2);
	oldPos = get(vec1Axis, 'pos');
	position = oldPos;
	position(1) = oldPos(1)+(oldPos(3)-dtwPlotWidth)/2;
	position(3) = dtwPlotWidth;
	set(vec1Axis, 'pos', position);
else
	% Adjust the axis of vec2
	dtwPlotHeight = position(3)*length(vec2)/length(vec1);
	oldPos = get(vec2Axis, 'pos');
	position = oldPos;
	position(2) = oldPos(2)+(oldPos(4)-dtwPlotHeight)/2;
	position(4) = dtwPlotHeight;
	set(vec2Axis, 'pos', position);
end

set(findobj(gcf, 'unit', 'pixel'), 'unit', 'normalize');

% ====== self demo ======
function selfdemo
vec1=[71 73 75 80 80 80 78 76 75 73 71 71 71 73 75 76 76 68 76 76 75 73 71 70 70 69 68 68 72 74 78 79 80 80 78];
vec2=[69 69 73 75 79 80 79 78 76 73 72 71 70 70 69 69 69 71 73 75 76 76 76 76 76 75 73 71 70 70 71 73 75 80 80 80 78];
[minDist1, dtwPath1, dtwTable1] = dtw1(vec1, vec2);
[minDist2, dtwPath2, dtwTable2] = dtw2(vec1, vec2);
feval(mfilename, vec1, vec2, dtwPath1, dtwPath2);
