function [bestMixNum, trainLogProb, testLogProb]=gmmGaussianNumEstimate(trainingData, testData, maxGaussianNum, covType, plotOpt)
% gmmMixNumEstimate: Estimate the number of mixture number of a GMM
%	Usage: bestMixNum=gmmGaussianNumEstimate(trainingData, testData, maxGaussianNum, covType, plotOpt)

%	Roger Jang, 20071222

if nargin<1, selfdemo; return; end
if nargin<3, maxGaussianNum=50; end
if nargin<4, covType=1; end
if nargin<5, plotOpt=0; end

trainLogProb=nan*zeros(1, maxGaussianNum);
testLogProb=nan*zeros(1, maxGaussianNum);
for i=1:maxGaussianNum
	[gmmParam, logProbHist] = gmmTrain(trainingData, [i, covType]);
	trainLogProb(i)=logProbHist(end);
	logProb2 = gmmEval(testData, gmmParam);
	testLogProb(i)=sum(logProb2);
	if plotOpt
		fprintf('%d/%d: training LP = %f, test LP = %f\n', i, maxGaussianNum, trainLogProb(i), testLogProb(i));
	end
end
plot(1:maxGaussianNum, trainLogProb, 'o-', 1:maxGaussianNum, testLogProb, 'square-');
[junk, bestMixNum]=max(testLogProb);
line(bestMixNum, testLogProb(bestMixNum), 'color', 'r', 'marker', '*');
legend('Training log prob', 'Test log prob');
grid on

% ====== Selfdemo
function selfdemo
data=dcdata(2);
data=data.input;
trainingData=data(:, 1:2:end);
testData =data(:, 2:2:end);
maxGaussianNum=50;
covType=1;
plotOpt=1;
bestMixNum=gmmGaussianNumEstimate(trainingData, testData, maxGaussianNum, covType, plotOpt);