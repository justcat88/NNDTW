function U = initfcm2(cluster_n, data_n)
%INITFCM2 Generate initial CRISP partition matrix for fuzzy c-means clustering.
%	U = INITFCM2(CLUSTER_N, DATA_N) randomly generates a CRISP partition
%	matrix U that is CLUSTER_N by DATA_N, where CLUSTER_N is number of
%	clusters and DATA_N is number of data points.
%	(Edited from initfcm.m by Roger, Sept-21-1996.)

U = zeros(cluster_n, data_n);
tmp = rand(cluster_n, data_n);
[junk, index] = max(tmp);
for i = 1:data_n,
	U(index(i), i) = 1;
end
