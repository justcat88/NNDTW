function out=decisionBoundaryPlot(xx, yy, class, color)
% decisionBoundaryPlot: Plot of the decision boundary of a classification problem

%	Roger Jang, 20041201

if nargin<1, selfdemo; return; end
if nargin<4, color='rgbkc'; end

classNum=length(class);

%pointNum=50;
%input=cat(2, class.input);
%x=linspace(min(input(1,:)), max(input(1,:)), pointNum);
%y=linspace(min(input(2,:)), max(input(2,:)), pointNum);
%[xx, yy] = meshgrid(x, y);
data = [xx(:), yy(:)]';

hold on
for i=1:classNum
	tempClass=class;
	tempClass(i)=[];
	maxSurf=max(cat(3, tempClass.surface), [], 3);
	tt=class(i).surface-maxSurf;
	[c, h]=contourf(xx, yy, tt, 0*[1 1]);
	class(i).contourx=get(h(1), 'xdata');
	class(i).contoury=get(h(1), 'ydata');
	colorIndex=mod(i-1, length(color))+1;
	patch('xdata', class(i).contourx, 'ydata', class(i).contoury, 'faceColor', color(colorIndex));
end
hold off
axis image;

% ====== selfdemo
function selfdemo
[xx, yy, zz]=peaks;
class(1).input=[min(xx(:)), max(xx(:)); min(yy(:)), max(yy(:))]
class(2).input=class(1).input;
class(1).surface=zz;
class(2).surface=0*zz+mean(zz(:));
feval(mfilename, xx, yy, class);