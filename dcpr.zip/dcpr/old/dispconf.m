function confusion = dispconf(computed, desired, string)
%DISPCONF Display (and return) the confusion count matrix
%	CONFUSION = DISPCONF(COMPUTED, ACTUAL, STRING)
%	CONFUSION: confusion count matrix
%	COMPUTED: computed label
%	ACTUAL: actual label
%	STRING: string to be displayed below the confusion plot

%	Roger Jang, June-28-1997

if nargin < 3, string = ''; end
computed = computed(:);
desired = desired(:);

classLabel = countele(desired);
classNum = length(classLabel);
% compute the confusion count matrix
confusion = zeros(classNum);
for i = 1:classNum,
	for j = 1:classNum,
		confusion(i,j) = sum((desired==classLabel(i)).* ...
				(computed==classLabel(j)));
	end
end

colordef black;
figure('name', 'Confusion plots', 'numberTitle', 'off');

subplot(2,2,1);
pltmat(confusion, 'Confusion matrix', 'c', 10);

prob = confusion./(sum(confusion')'*ones(1, size(confusion,1)));
overall = sum(diag(confusion))/sum(sum(confusion));
new_prob = fix(prob*1000)/10;
new_overall = fix(overall*1000)/10;
subplot(2,2,2);
pltmat(new_prob, ['Overall recognition rate = ', num2str(new_overall), '%'], 'c', 9);
% Add the percentage sign
textH = findobj(gca, 'type', 'text');
for i=1:length(textH),
	str = get(textH(i), 'string');
	set(textH(i), 'string', [str, '%']);
end
xlabel(string)

