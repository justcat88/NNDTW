function lcsPathPlot(str1, str2, lcsPath, lcsStr, lcsTable)
% lcsPathPlot: Plot the path of LCS

%	Roger Jang, 20060528

m = length(str1);
n = length(str2);
%[xx, yy] = meshgrid(1:m, 1:n);
%plot(xx(:), yy(:), '.');
axis([0 m+1 0 n+1]);
box on;
set(gca, 'xtick', 1:m);
set(gca, 'ytick', 1:n);
set(gca, 'xticklabel', char(double(str1)'));
set(gca, 'yticklabel', char(double(str2)'));

xlabel(['String1 = ', str1]);
ylabel(['String2 = ', str2]);
title(['LCS table and LCS path; with LCS = ', lcsStr]);

% ====== Plot LCS table
for i = 1:m,
	for j = 1:n,
		text(i, j, int2str(lcsTable(i,j)), 'hori', 'center');
	end
end

% ====== Plot LCS path
for i = 1:size(lcsPath,1)-1,
	line(lcsPath(i:i+1, 1), lcsPath(i:i+1, 2));
end

% ====== Circle matched elements
temp = lcsTable((lcsPath(:,2)-1)*m+lcsPath(:,1)); % LCS count along the path
temp = [0; temp];
index = find(diff(temp));
match_point = lcsPath(index, :);
line(match_point(:,1), match_point(:, 2), 'marker', 'o', 'markersize', 15, 'color', 'r', 'linestyle', 'none');