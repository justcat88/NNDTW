function NODE = genbbt(data, clusterNum, levelNum);
% GENBBT Generate BBT (Branch and Bound Tree) for nearest neighbor search
%	Usage: NODE = genbbt(data, clusterNum, levelNum)
%		data: Data matrix with each row a data vector
%		clusterNum: No. of clusters (or children) for each node
%		levelNum: No. of level of the BB tree
%		NODE: A vector representing the BB tree
%
%	Field of NODE:
%		NODE(i).mean: mean vector of a tree node
%		NODE(i).radius: radius vector of a tree node
%		NODE(i).child: indices of children for a non-terminal node
%		NODE(i).data: indices of data for a terminal node
%		NODE(i).dist2mean: distance to mean of a terminal node

global NODENUM NODE
if nargin<3, levelNum = 4; end
if nargin<2, clusterNum = 3; end
if nargin<1, data = rand(1000,2); end

dataNum = size(data, 1);
dimNum = size(data, 2);
if dimNum==2,
	plot(data(:,1), data(:,2), '.');
end
NODENUM = 0;
maketree(data, 1:dataNum, clusterNum, NODENUM, levelNum);
if dimNum==2, axis equal; end

% ====== Sub function
function maketree(data, index, clusterNum, parent, level)
global NODENUM NODE
NODENUM = NODENUM+1;
if parent~=0
	NODE(parent).child = [NODE(parent).child NODENUM]; 
end
NODE(NODENUM).mean = mean(data);
dist2mean = zeros(size(data,1),1);
for i=1:size(data,1),
	dist2mean(i) = norm(data(i,:)-NODE(NODENUM).mean);
end
NODE(NODENUM).radius = max(dist2mean);
NODE(NODENUM).child = [];

if size(data,2)==2,
	x=data(:,1);
	y=data(:,2);
	k=convhull(x,y);
	color = {'y', 'k', 'm', 'g', 'r', 'c'};
	line(x(k), y(k), 'linestyle', '-', 'marker', 'o', ...
		'color', color{rem(level, length(color))+1}, ...
		'linewidth', level);
end

if level==1 | size(data,1)==1	% Terminal node
	NODE(NODENUM).data = index;
	% NODE(NODENUM).dist2mean is the distance of each data to mean
	NODE(NODENUM).dist2mean = dist2mean;
	return;
end

[center, U, objFcn] = vqKmeans(data', clusterNum, 0); center=center'; 
parent = NODENUM;
for i = 1:clusterNum,
	index0 = find(U(i, :) == 1);
	index1 = index(index0);
	data1 = data(index0, :);
	maketree(data1, index1, clusterNum, parent, level-1);
end
