function [inData2, removedFeaIndex] = removeSameValueFeature(inData)
% removeSameValueFeature: Remove same-value features
%	Usage: [inData2, removedFeaIndex] = removeSameValueFeature(inData)
%
%	Roger Jang, 20060818

if nargin<1, selfdemo; return; end

removedFeaIndex=sameValueRow(inData);
inData2=inData;
inData2(removedFeaIndex, :)=[];

% ====== Self demo
function selfdemo
inData=[1 2 3 9 ; 1 5 7 9; 1 8 2 9; 1 7 2 9; 1 3 5 9]';
[inData2, removedFeaIndex]=feval(mfilename, inData);
fprintf('inData=\n'); disp(inData);
fprintf('[inData2, removedFeaIndex]==%s(inData) produces\n', mfilename);
fprintf('inData2=\n'); disp(inData2);
fprintf('removedFeaIndex=\n'); disp(removedFeaIndex);