% Test k-means on 2-D data
close all;
dataNum = 100;
data1 = ones(dataNum, 1)*[0 0] + randn(dataNum, 2)/5;
data2 = ones(dataNum, 1)*[0 1] + randn(dataNum, 2)/5;
data3 = ones(dataNum, 1)*[1 0] + randn(dataNum, 2)/5;
data = [data1; data2; data3]';
clusterNum=10;
plotOpt=1;
[center, U, obj_fcn] = vqKmeans(data, clusterNum, plotOpt);