function overall=confMatPlot(confMat, className)
%confMatPlot: Display the confusion matrix
%	Usage: confMatPlot(confMat, className)
%
%	For example:
%		desired=[1 1 1 1 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2 2 2 2 2 2 3 3 3 3 3 3 3 3 3 3 3 3 4 4 4 4 4 4 4 4 4 4 4 5 5 5 5 5 5 5 5 5 5 5 5];
%		computed=[1 5 5 1 1 1 1 1 5 5 1 2 2 2 2 2 2 2 2 2 2 2 2 2 3 3 3 3 3 3 3 3 3 3 3 3 4 4 4 4 4 4 4 4 4 4 2 5 5 5 5 5 5 5 5 3 5 5 5];
%		confMat = confMatGet(desired, computed);
%		className={'Canada', 'China', 'Japan', 'Taiwan', 'US'};
%		confMatPlot(confMat, className);

%	Roger Jang, 20060421, 20070504

if nargin<1, selfdemo; return; end
if nargin<2
	for i=1:size(confMat, 1)
		className{i}=int2str(i);
	end
end

%colordef black;
fontSize=10;
subplot(1,2,1);
str='Conf. mat. of data counts';
matPlot(confMat, str, 'k', fontSize, 'b', className, className);

prob = confMat./(sum(confMat')'*ones(1, size(confMat,1)));
overall = sum(diag(confMat))/sum(sum(confMat));
new_prob = round(prob*10000)/100;
new_overall = round(overall*10000)/100;
subplot(1,2,2);
str1='Conf. mat. of recog. rates (%)';
str2=['Overall recognition rate = ', num2str(new_overall), '%'];
matPlot(new_prob, strvcat(str1, str2), 'k', fontSize, 'b', className, className);
% Add the percentage sign
%textH = findobj(gca, 'type', 'text');
%for i=1:length(textH),
%	str = get(textH(i), 'string');
%	set(textH(i), 'string', [str, '%']);
%end

% ====== Self demo
function selfdemo
desired=[1 1 1 1 1 1 1 1 1 1 1 1 2 2 2 2 2 2 2 2 2 2 2 2 3 3 3 3 3 3 3 3 3 3 3 3 4 4 4 4 4 4 4 4 4 4 4 5 5 5 5 5 5 5 5 5 5 5 5];
computed=[1 5 5 1 1 1 1 1 5 5 1 2 2 2 2 2 2 2 2 2 2 2 2 2 3 3 3 3 3 3 3 3 3 3 3 3 4 4 4 4 4 4 4 4 4 4 2 5 5 5 5 5 5 5 5 3 5 5 5];
confMat = confMatGet(desired, computed);
className={'Canada', 'China', 'Japan', 'Taiwan', 'US'};
feval(mfilename, confMat, className);