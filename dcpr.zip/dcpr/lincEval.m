function [lincOutput, recogRate, errorIndex1, errorIndex2, regOutput, regError]=lincEval(DS, coef)
% lincEval: Evaluation of linear classifier
%	Usage: [lincOutput, recogRate, errorIndex1, errorIndex2, regOutput, regError]=lincEval(DS, coef)

%	Roger Jang, 20041106

[dim, dataNum]=size(DS.input);
% Preapre A matrix for A*x=desired
regOutput=coef'*[DS.input; ones(1, dataNum)];	% Regression output
lincOutput=-ones(1, dataNum);			% Classification output
lincOutput(regOutput>0)=1;

if isfield(DS, 'output')
	desired=-ones(1, dataNum);
	desired(DS.output>0)=1;
	recogRate=sum(lincOutput==desired)/dataNum;	% Classification recognition rate
	errorIndex1=find(desired<0 & lincOutput>0);	% - ===> +
	errorIndex2=find(desired>0 & lincOutput<0);	% + ===> -
	regError=sum((regOutput-desired).^2);		% Regression MSE
	errorIndex1=find(desired<0 & lincOutput>0);	% - ===> +
	errorIndex2=find(desired>0 & lincOutput<0);	% + ===> -
end