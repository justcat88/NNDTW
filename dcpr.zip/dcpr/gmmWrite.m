function gmmWrite(gmm, gmmFile, useInt, weightSf)
%gmmWrite: Write the parameters of a GMM to a file
%	Usage: gmmWrite(gmm, gmmFile, useInt)
%		gmm: gmm structure
%		gmmFile: output file
%		useInt: use integer format (for fixed-point operation)
%		weightSf: scaling factor of weights (This should be the same as those used in goLog.m, goLogSum.m for generating C tables.)

%	Roger Jang, 20070627, 20080728

if nargin<3, useInt=0; end
if nargin<4, weightSf=1; end

if ~isfield(gmm, 'name')
	gmm.name='None';
end

dim=length(gmm.gmmParam(1).mu);
mixNum=length(gmm.gmmParam);

fid=fopen(gmmFile, 'w');
fprintf(fid, '<comment>\r\n%s\r\n', 'Put your comments here!');
fprintf(fid, '<version>\r\n%s\r\n', '1.0');
fprintf(fid, '<gmmType>\r\n%d\r\n', 1);
fprintf(fid, '<name>\r\n%s\r\n', gmm.name);
fprintf(fid, '<dim>\r\n%d\r\n', dim);
fprintf(fid, '<mixNum>\r\n%d\r\n', mixNum);
% ====== Write mean
fprintf(fid, '<mean>\r\n');
for i=1:mixNum
	for j=1:dim
		if useInt==0
			fprintf(fid, '%e ', gmm.gmmParam(i).mu(j));
		else
			fprintf(fid, '%d ', round(gmm.gmmParam(i).mu(j)));
		end
	end
	fprintf(fid, '\r\n');
end
fprintf(fid, '<covariance>\r\n');
% ====== Write covariance
for i=1:mixNum
	if useInt==0
		fprintf(fid, '%e ', gmm.gmmParam(i).sigma);
	else
		fprintf(fid, '%d ', round(gmm.gmmParam(i).sigma));
	end
end
fprintf(fid, '\r\n');
% ====== Write weight
fprintf(fid, '<weight>\r\n');
for i=1:mixNum
	if useInt==0
		fprintf(fid, '%e ', gmm.gmmParam(i).w);
	else
		fprintf(fid, '%d ', round(weightSf*gmm.gmmParam(i).w));
	end
end
fprintf(fid, '\r\n');
% ====== Write gConst
fprintf(fid, '<gConst>\r\n');
for i=1:mixNum
	gConst=dim*log(2*pi*gmm.gmmParam(i).sigma);
	if useInt==0
		fprintf(fid, '%e ', gConst);
	else
		fprintf(fid, '%d ', round(weightSf*gConst));
	end
end

fclose(fid);