function out=interpDist(x, sampleData)
% DISTINTERP	�H�Z�����˼Ƭ��v���Ӷi�氪�����t�B��

if nargin==0, selfdemo; return; end

dataNum=size(sampleData,1);
inputNum=size(sampleData,2)-1;
input=sampleData(:, 1:end-1);
output=sampleData(:, end);
distance=zeros(dataNum,1);

% Normalization of sample data
colMin=min(input);
colMax=max(input);
for i=1:inputNum,
	sampleData(:,i)=(sampleData(:,i)-colMin(i))/(colMax(i)-colMin(i));
end
% Normalization of test data
x=(x-colMin)./(colMax-colMin);

for i=1:dataNum,
	distance(i)=distanceFunction(x, sampleData(i, 1:end-1));
end

[minDist, index]=min(distance);
if minDist<1e-8,
	out=output(index);
	return;
end

weight=1./distance;
out=(weight'*output)/sum(weight);

% ====== subfunction
function out=distanceFunction(x, y)
out=norm(x-y)^3;

% ====== subfunction for selfdemo
function selfdemo
sampleData=[1 3; 2 5; 3 6; 5 7; 7 8; 6 7.5];
x=linspace(min(sampleData(:,1)), max(sampleData(:,1)));
y=0*x;
for i=1:length(y);
	y(i)=feval(mfilename, x(i), sampleData);
end
figure;
plot(x, y);
hold on
plot(sampleData(:,1), sampleData(:,2), 'o');
hold off

sampleData=[0 3 4; 1 4 2; 3 1 6; 2 4 3; 4 2 1; 2 3 1; 4 4 0];
pointNum=20;
x=linspace(min(sampleData(:,1)), max(sampleData(:,1)), pointNum);
y=linspace(min(sampleData(:,2)), max(sampleData(:,2)), pointNum);
z=zeros(length(x), length(y));
for i=1:length(x)
	for j=1:length(y)
		z(j,i)=feval(mfilename, [x(i), y(j)], sampleData);
	end
end
figure;
mesh(x, y, z);
h=line(sampleData(:,1), sampleData(:,2), sampleData(:,3), 'marker', 'o', 'linestyle', 'none');
xlabel('X'); ylabel('Y'); zlabel('Z');
title(['Interpolation surface using ', mfilename]);
view(-140, 50);
box on
rotate3d on
axis tight