% ====== Self demo ======
clear all

data_n = 20;
dimension = 2;
points = rand(data_n, dimension);
% Compute the distance matrix
for i = 1:data_n
    for j = 1:data_n
        distance(i, j) = norm(points(i,:)-points(j,:));
    end
end
% Diagonal elements should always be inf.
for i = 1:data_n, distance(i, i) = inf; end
 
level = aggclust(distance);
 
% Plot the dendrogram
figure;
dendro(level);
fprintf('The figure is a dendrogram (single-linkage) of 50 random points in 2D\n');