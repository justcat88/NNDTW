function [DS, TS]=prData(dataName)
% prData: Various data set for PR
%	Usage: [DS, TS]=prData(dataName)
%		dataName: 'irir', 'wine', 'abalone', 'random2', 'random6'

%	Roger Jang

if nargin<1, selfdemo; return; end

switch lower(dataName)
	case 'iris'
		load iris.dat
		DS.dataName='iris';
		inputName={'sepal length', 'sepal width', 'petal length', 'petal width'};
		[DS.inputName]=deal(inputName);
		outputName={'Iris Setosa', 'Iris Versicolour', 'Iris Virginica'};
		outputName={'Setosa', 'Versicolour', 'Virginica'};
		[DS.outputName]=deal(outputName);
		DS.input=iris(:, 1:end-1)';
		DS.output=iris(:, end)';
		if nargout==2
			dataNum=size(DS.input, 2);
			TS=DS;
			DS.input= DS.input(:, 1:2:dataNum);
			DS.output=DS.output(:, 1:2:dataNum);
			TS.input= TS.input(:, 2:2:dataNum);
			TS.output=TS.output(:, 2:2:dataNum);
		end
	case 'wine'
		load wine.dat
		DS.dataName='wine';
		inputName={'Alcohol', 'Malic acid', 'Ash', 'Alcalinity of ash', 'Magnesium', 'Total phenols', 'Flavanoids', 'Nonflavanoid phenols', 'Proanthocyanins', 'Color intensity', 'Hue', 'OD280/OD315 of diluted wines', 'Proline'};
		[DS.inputName]=deal(inputName);
		DS.input=wine(:, 2:end)';
		DS.output=wine(:, 1)';
		if nargout==2
			dataNum=size(DS.input, 2);
			TS=DS;
			DS.input= DS.input(:, 1:2:dataNum);
			DS.output=DS.output(:, 1:2:dataNum);
			TS.input= TS.input(:, 2:2:dataNum);
			TS.output=TS.output(:, 2:2:dataNum);
		end
	case 'abalone'
		load abalone.dat
		DS.dataName='abalone';
		inputName={'Sex', 'Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight'};
		[DS.inputName]=deal(inputName);
		DS.input=abalone(:, 1:end-1)';
		DS.output=abalone(:, end)';
		if nargout==2
			dataNum=size(DS.input, 2);
			TS=DS;
			DS.input= DS.input(:, 1:2:dataNum);
			DS.output=DS.output(:, 1:2:dataNum);
			TS.input= TS.input(:, 2:2:dataNum);
			TS.output=TS.output(:, 2:2:dataNum);
		end
	case 'random2'		% 2D random data
		n=100;
		dim=2;
		c1 = [0.125 0.25]'; data1 = randn(dim,n)/8 + c1*ones(1,n); out1 = 1*ones(1,n);
		c2 = [0.625 0.25]'; data2 = randn(dim,n)/8 + c2*ones(1,n); out2 = 2*ones(1,n);
		c3 = [0.375 0.75]'; data3 = randn(dim,n)/8 + c3*ones(1,n); out3 = 3*ones(1,n);
		c4 = [0.875 0.75]'; data4 = randn(dim,n)/8 + c4*ones(1,n); out4 = 4*ones(1,n);
		data = [data1, data2, data3, data4];
		out = [out1, out2, out3, out4];
		DS.input=data;
		DS.output=out;
		DS.dataName='random2';
		if nargout==2
			dataNum=size(DS.input, 2);
			TS=DS;
			DS.input= DS.input(:, 1:2:dataNum);
			DS.output=DS.output(:, 1:2:dataNum);
			TS.input= TS.input(:, 2:2:dataNum);
			TS.output=TS.output(:, 2:2:dataNum);
		end
	case 'random3'		% 3D random data
		dataNum=100;
		mean1=[0 0 0]';
		input1=randn(3, dataNum)+mean1*ones(1,dataNum);
		output1=1*ones(1, dataNum);
		mean2=[0 5 5]';
		input2=randn(3, dataNum)+mean2*ones(1,dataNum);
		output2=2*ones(1, dataNum);
		mean3=[3 2 4]';
		input3=randn(3, dataNum)+mean3*ones(1,dataNum);
		output3=3*ones(1, dataNum);
		DS.input=[input1, input2, input3];
		DS.output=[output1, output2, output3];
	case 'random6'		% 6D random data
		n=50;
		dim=6;
		c1 = [1 0 0 0 0 0]'; data1 = randn(dim,n)/4 + c1*ones(1,n); out1 = 1*ones(1,n);
		c2 = [0 1 0 0 0 0]'; data2 = randn(dim,n)/4 + c2*ones(1,n); out2 = 2*ones(1,n);
		c3 = [0 0 1 0 0 0]'; data3 = randn(dim,n)/4 + c3*ones(1,n); out3 = 3*ones(1,n);
		c4 = [0 0 0 1 0 0]'; data4 = randn(dim,n)/4 + c4*ones(1,n); out4 = 4*ones(1,n);
		data = [data1, data2, data3, data4];
		out = [out1, out2, out3, out4];
		DS.input=data;
		DS.output=out;
		DS.dataName='random6';
		if nargout==2
			dataNum=size(DS.input, 1);
			TS=DS;
			DS.input= DS.input(:, 1:2:dataNum);
			DS.output=DS.output(:, 1:2:dataNum);
			TS.input= TS.input(:, 2:2:dataNum);
			TS.output=TS.output(:, 2:2:dataNum);
		end
	otherwise
		disp('Unknown method.')
end

if ~isfield(DS, 'inputName')
	for i=1:size(DS.input,1)
		DS.inputName{i}=int2str(i);
		if exist('TS')
			TS.inputName{i}=int2str(i);
		end
	end
end

% ======= Self demo
function selfdemo
subplot(2,2,1);
DS=feval(mfilename, 'random2'); dcprDataPlot(DS);
subplot(2,2,2);
DS=feval(mfilename, 'iris'); dcprDataPlot(DS);
subplot(2,2,3);
DS=feval(mfilename, 'wine'); dcprDataPlot(DS);
subplot(2,2,4);
DS=feval(mfilename, 'abalone'); dcprDataPlot(DS);
