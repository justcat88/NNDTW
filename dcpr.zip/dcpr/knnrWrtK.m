function [misclassify, elapsed_time] = knnrWrtK(DS, TS, kMax, plotOpt)
% knnrWrtK: Try various values of K in leave-one-out K-NNR.
%	[misclassify, elapsed_time] = knnrWrtK(sampledata, k_max, big_dataset, plotting)

%	Roger Jang, 971227, 990613

if nargin<1, selfdemo; return; end
if nargin<3, kMax=15; end
if nargin<4, plotOpt=0; end

designNum=size(DS.input, 2);
testNum  =size(TS.input, 2);
for k=1:kMax
	knnrParam.k=k;
	computed=knnr(DS, TS, knnrParam);
	correctCount=sum(TS.output==computed);
	recog(k)=correctCount/testNum;
	fprintf('\t%d-NNR ===> 1-%d/%d = %.2f%%.\n', k, testNum-correctCount, testNum, recog(k)*100);
end

if plotOpt
	plot(1:kMax, recog*100, 'b-o'); grid on;
	title('Recognition rates of Iris data using K-NNR');
	xlabel('K'); ylabel('Recognition rates (%)');
end


function selfdemo
[DS, TS]=prData('iris');
designNum=size(DS.input, 2);
testNum  =size(TS.input, 2);
fprintf('Use of KNNR for Iris data:\n');
fprintf('\tSize of design set (odd-indexed data)= %d\n', designNum);
fprintf('\tSize of test set (even-indexed data) = %d\n', testNum);
kMax=15;
plotOpt=1;
knnrWrtK(DS, TS, kMax, plotOpt);