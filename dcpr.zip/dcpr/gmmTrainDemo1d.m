% Example of using GMM (gaussian mixture model) for 1-D data

% ====== �e�X��ƽ��ϡ]Histogram�^
DS = dcData(7); data = DS.input;
subplot(2,1,1);
binNum = 30;
hist(data, binNum);
xlabel('Data values'); ylabel('Counts'); title('Data histogram');
colormap(summer);
% ====== �i�� GMM �V�m
gaussianNum = 3;
covType=1;
gmmTrainParam=gmmTrainParamSet; gmmTrainParam.dispOpt=1;
[gmmParam, lp]=gmmTrain(data, [gaussianNum, covType], gmmTrainParam);
% ====== �e�X log probability �b�V�m�L�{���ܤ�
subplot(2,1,2);
plot(lp, 'o-');
xlabel('No. of iterations of GMM training');
ylabel('Log probability');
% ====== �L�X�V�m���G
fprintf('w1=%g, mu1=%g, v1=%g\n', gmmParam(1).w, gmmParam(1).mu, gmmParam(1).sigma);
fprintf('w2=%g, mu2=%g, v2=%g\n', gmmParam(2).w, gmmParam(2).mu, gmmParam(2).sigma);
fprintf('w3=%g, mu3=%g, v3=%g\n', gmmParam(3).w, gmmParam(3).mu, gmmParam(3).sigma);
fprintf('Overall logProb = %g\n', sum(log(gmmEval(data, gmmParam))));

figure
% ====== �e�X��ƽ��ϡ]Histogram�^
subplot(2,1,1);
binNum = 30;
hist(data, binNum);
xlabel('Data values'); ylabel('Counts'); title('Data histogram');
colormap(summer);
bound = axis;
x = linspace(bound(1), bound(2));
% ====== �e�X�w�������v�K�ר��
subplot(2,1,2);
hold on
for i = 1:gaussianNum,
	h1 = plot(x, gaussian(x, gmmParam(i)), '--m');
	set(h1, 'linewidth', 2);
end
for i = 1:gaussianNum,
	h2 = plot(x, gaussian(x, gmmParam(i))*gmmParam(i).w, ':b');
	set(h2, 'linewidth', 2);
end
total = zeros(size(x));
for i = 1:gaussianNum,
	g(i,:)=gaussian(x, gmmParam(i));
	total=total+g(i, :)*gmmParam(i).w;
end
h3 = plot(x, total, 'r');
set(h3, 'linewidth', 2);
hold off
box on
legend([h1 h2 h3], 'g_i', 'w_ig_i', '\Sigma_i w_ig_i');
xlabel('Data values'); ylabel('Prob.'); title('Gaussian mixture model');
% ���W g1, g2, g3
for i=1:gaussianNum
	[maxValue, index]=max(g(i, :));
	text(x(index), maxValue, ['g_', int2str(i)], 'vertical', 'bottom', 'horizon', 'center');
end
% ====== �e�X�|�[�� histogram �����u
k = size(data,2)*(max(data)-min(data))/binNum;
subplot(2,1,1)
line(x, total*k, 'color', 'r', 'linewidth', 2);