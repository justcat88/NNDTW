function [classSize, classLabel] = classDataCount(DS, plotOpt)
%classSize: Class sizes for a sample data set
%	Usage: [classSize, classLabel] = classDataCount(DS, plotOpt)
%
%	For example:
%		DS=prData('abalone');
%		[classSize, classLabel]=classDataCount(DS, 1);

%	Roger Jang, 1997xxxx, 20041208, 20080827

if nargin<1, selfdemo; return; end
if nargin<2, plotOpt=0; end

[featureNum, dataNum] = size(DS.input);		% no. of features
[classLabel, classSize] = elementCount(DS.output);

% Plot class data distribution
if plotOpt
	fprintf('%g features\n', featureNum);
	fprintf('%g instances\n', dataNum);
	fprintf('%g classes\n', length(classLabel));
	bar(classLabel, classSize);
	xlabel('Classes');
	ylabel('Class sizes');
	if isfield(DS, 'dataName'), title(sprintf('Class distribution for "%s"', DS.dataName)); end
end

% ====== Self demo
function selfdemo
DS=prData('abalone');
plotOpt=1;
feval(mfilename, DS, plotOpt);