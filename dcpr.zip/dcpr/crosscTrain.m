function [recogRate, coef]=crosscTrain(DS, CParam, plotOpt)
% crosscTrain: Cross classifier training
%	Usage: [recogRate, coef]=crosscTrain(DS, CParam, plotOpt)

% Roger Jang, 20041216

if nargin<1, selfdemo; return; end
if nargin<2, CParam=[]; end
if nargin<3, plotOpt=0; end

[dim, dataNum]=size(DS.input);
% Preapre A matrix for A*x=desired
A=[DS.input', ones(dataNum,1)];
uniqueOutput=unique(DS.output);
if length(uniqueOutput)~=2, error('Must be 2-class problem!'); end
if size(DS.input, 1)==1
	[recogRate, coef]=lincTrainMre(DS, CParam, plotOpt);
	return;
end
if size(DS.input, 1)>2, error('Must be 1D or 2D problem!'); end

% �N DS.output �令 -1 �� 1
index=find(DS.output==max(uniqueOutput));
DS.output=-ones(1, size(DS.output,2));
DS.output(index)=1;

xMin=min(DS.input(1,:));
xMax=max(DS.input(1,:));
yMin=min(DS.input(2,:));
yMax=max(DS.input(2,:));

n=21;
x=linspace(xMin, xMax, n);
y=linspace(yMin, yMax, n);
allRecogRate=zeros(n);
for i=1:n
	for j=1:n
		coef0{1}=[x(i), y(j), 0, 0, 0];
		[output, tmp(1)]=crosscEval(DS, coef0{1});
		coef0{2}=[x(i), y(j), 0, 0, 1];
		[output, tmp(2)]=crosscEval(DS, coef0{2});
		coef0{3}=[x(i), y(j), 0, 1, 0];
		[output, tmp(3)]=crosscEval(DS, coef0{3});
		coef0{4}=[x(i), y(j), 0, 1, 1];
		[output, tmp(4)]=crosscEval(DS, coef0{4});
		coef0{5}=[x(i), y(j), 1, 0, 0];
		[output, tmp(5)]=crosscEval(DS, coef0{5});
		coef0{6}=[x(i), y(j), 1, 0, 1];
		[output, tmp(6)]=crosscEval(DS, coef0{6});
		coef0{7}=[x(i), y(j), 1, 1, 0];
		[output, tmp(7)]=crosscEval(DS, coef0{7});
		coef0{8}=[x(i), y(j), 1, 1, 1];
		[output, tmp(8)]=crosscEval(DS, coef0{8});
		[allRecogRate(i,j), index]=max(tmp);
		allCoef{i,j}=coef0{index};
	end
end

% Find the best recog. rate
recogRate=max(max(allRecogRate));
[i,j]=find(allRecogRate==recogRate);
i=i(1); j=j(1);			% �u���Ĥ@��
coef=allCoef{i,j};

if plotOpt & dim==2
	dcprDataPlot(DS); axis image
	axisLimit=axis;
	line(coef(1)*[1, 1], axisLimit(3:4), 'color', 'k');
	line(axisLimit(1:2), coef(2)*[1, 1], 'color', 'k');
end

% ====== Self demo
function selfdemo
dataNum=100;
DS.input=2*rand(2, dataNum)-1;
DS.output=DS.input(1,:)+DS.input(2,:)>0;
plotOpt=1;
[recogRate, coef]=feval(mfilename, DS, [], plotOpt);
fprintf('Recognition rate = %f%%\n', recogRate*100);
fprintf('Coef = %s\n', mat2str(coef));