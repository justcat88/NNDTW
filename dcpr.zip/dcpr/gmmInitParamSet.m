function gmmParam=gmmInitParamSet(data, gaussianNum, covType, gmmTrainParam);
% gmmParamSet: Set a set of initial parameters for GMM
%	Usage: gmmParam=gmmInitParamSet(data, gaussianNum, covType, gmmTrainParam);

%	Roger Jang, 20080726

if nargin<2, gaussianNum=3; end
if nargin<3, covType=1; end
if nargin<4, gmmTrainParam=gmmTrainParamSet; end
[dim, dataNum]=size(data);

for i=1:gaussianNum
	gmmParam(i).mu = zeros(dim, 1);
	gmmParam(i).w = 1/gaussianNum;
	switch covType
		case 1
			gmmParam(i).sigma = 1;
		case 2
			gmmParam(i).sigma = ones(dim, 1);
		case 3
			gmmParam(i).sigma = diag(ones(dim, 1));
		otherwise
			disp('Unknown covType!')
	end
end

% === Set the mean vectors
% Here we try several methods to find the initial mean vectors
if gmmTrainParam.useKmeans
	if gmmTrainParam.dispOpt, fprintf('\tStart KMEANS to find the initial mean vectors...\n'); end
%	muMat = vqKmeansMex(data, gaussianNum, 0);			% Method 1: Fast but less robust
	muMat = vqKmeans(data, gaussianNum, 0);			% Method 2: Slow but more robust
	if any(any(~isfinite(muMat)))
		muMat = vqLBG(data, gaussianNum, 0);			% Try another method of vqLBG
	end
	if any(any(~isfinite(muMat)))
		muMat = data(:, 1+floor(rand(gaussianNum,1)*dataNum));	% Try another method of random selection
	end	
else
	muMat = data(:, 1+floor(rand(gaussianNum,1)*dataNum));	% Randomly select several data points as the centers
end
% Set the intitial mean vectors of gmmParam
meanCell=mat2cell(muMat, dim, ones(1, gaussianNum));
[gmmParam.mu]=deal(meanCell{:});

% ====== Set the initial covariance matrix
dataRange=max(data, [], 2)-min(data, [], 2);
if gmmTrainParam.useKmeans
	% ====== Set the initial covariance matrix as the min squared distance between centers
	sqrDist=pairwiseSqrDistance(muMat);
%	sqrDist(1:(gaussianNum+1):gaussianNum^2)=inf;	% Diagonal elements are inf
	meanSqrDist = mean(mean(sqrDist))/2*log(2);;			% Initial variance for each Gaussian
	meanSqrDist = max(meanSqrDist, gmmTrainParam.minVariance);
	if gaussianNum==1, meanSqrDist=(mean(dataRange)/5)^2; end	% If there is only a single Gaussian, set it to a reasonable value
	% Set the initial covariance matrix of gmmParam
	for i=1:gaussianNum
		gmmParam(i).sigma=meanSqrDist*gmmParam(i).sigma;
	end
else
	% ====== Set the initial covariance matrix by the range of the input data
	switch covType
		case 1
			for i=1:gaussianNum
				gmmParam(i).sigma = (mean(dataRange)/5)^2;
			end
		case 2
			for i=1:gaussianNum
				gmmParam(i).sigma = (dataRange/5).^2;
			end
		case 3
			for i=1:gaussianNum
				gmmParam(i).sigma = diag((dataRange/5).^2);
			end
		otherwise
			disp('Unknown covType!')
	end
end
