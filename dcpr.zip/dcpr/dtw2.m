function [minDist, dtwPath, dtwTable]=dtw2(vec1, vec2, beginCorner, endCorner, plotOpt, distanceBound)
% dtw2: Dynamic time warping with local paths of 0, 45, and 90 degrees
%	Usage: [minDist, dtwPath, dtwTable] = dtw2(vec1, vec2, beginCorner, endCorner, plotOpt, distanceBound)
%		vec1: testing vector
%		vec2: reference vector
%		beginCorner: 1 for anchored beginning
%		endCorner: 1 for anchored ending
%		plotOpt: 1 for plotting the DTW path
%		minDist: minimun distance of DTW
%		dtwPath: optimal path of DTW (Its size is 2xk, where k is the path length.)
%		dtwTable: DTW table
%
%	For example:
%		vec1=[71 73 75 80 80 80 78 76 75 73 71 71 71 73 75 76 76 68 76 76 75 73 71 70 70 69 68 68 72 74 78 79 80 80 78];
%		vec2=[69 69 73 75 79 80 79 78 76 73 72 71 70 70 69 69 69 71 73 75 76 76 76 76 76 75 73 71 70 70 71 73 75 80 80 80 78];
%		[minDist, dtwPath, dtwTable] = dtw2(vec1, vec2);
%		dtwplot(vec1, vec2, dtwPath);

%	Roger Jang, 20030404, 20060614

if nargin<1, selfdemo; return; end
if nargin<3, beginCorner=1; end
if nargin<4, endCorner=1; end
if nargin<5, plotOpt=0; end
if nargin<6, distanceBound=inf; end

% If input is vector, make it row vector
if size(vec1,1)==1 | size(vec1,2)==1, vec1 = vec1(:)'; end
if size(vec2,1)==1 | size(vec2,2)==1, vec2 = vec2(:)'; end

if nargout<2
	minDist=dtw2mex(vec1, vec2, beginCorner, endCorner, distanceBound);
else
	[minDist, dtwPath, dtwTable]=dtw2mex(vec1, vec2, beginCorner, endCorner, distanceBound);
end

% Plotting if necessary
if plotOpt==1, dtwplot(vec1, vec2, dtwPath); end

% ====== Self demo
function selfdemo
% vec1=[71 73 75 80 80 80 78 76 75 73 71 71 71 73 75 76 76 68 76 76 75 73 71 70 70 69 68 68 72 74 78 79 80 80 78];
% vec2=[69 69 73 75 79 80 79 78 76 73 72 71 70 70 69 69 69 71 73 75 76 76 76 76 76 75 73 71 70 70 71 73 75 80 80 80 78];
vec1=[100 102 106 110 105 110 102 108 95 97 99 100 100 102 104 106 106 89 94 95 95 92 88 88 88 89 85 87 95 95 99 99 100 100];
vec2=[98 99 90 95 99 100 109 108 106 103 102 101 100 100 99 99 99 101 103 105 106 106 106 106 106 105 103 101 90 90 101 103 105 100 100 100 108];

[minDist, dtwPath, dtwTable] = dtw2(vec1, vec2);
dtwplot(vec1, vec2, dtwPath);